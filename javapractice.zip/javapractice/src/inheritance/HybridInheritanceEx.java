package inheritance;

public class HybridInheritanceEx {

}
class Watch3{
	
}
class SmartWatch1 extends Watch3 {
	
}
class AppleWatch1 extends SmartWatch1{
	
}
class SamsungWatch extends SmartWatch1{
	
}
