package inheritance;

public class MultiLevelInheritanceEx {

}
class Watch{
	
}
class SmartWatch extends Watch{
	
}
class AppleWatch extends SmartWatch{
	
}

