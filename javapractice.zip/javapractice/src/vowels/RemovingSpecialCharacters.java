package vowels;

public class RemovingSpecialCharacters {
	
	
	public static void main(String[] args) {
		
		String x = "Congrats Kavutham !!!. It was a wonderful program. You offer code is !abc123...$%";
		char a[] = x.toCharArray();
		int count = 0 ; 
		for (int i =0; i < a.length ; i++)
		{
			if (a[i] == '!'|| a[i ] == '$'||a[i] == '%')
			{
				count++;
				
			}
		
		}
		System.out.println("no of special characters is "+count);
		
	}

}
