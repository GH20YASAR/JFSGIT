package vowels;

public class FindingVowels {
	public static void main(String[] args) {
		String x = "it is a great day today. let us learn java";
		
		char ch[] = x.toCharArray();
	int count = 0;
	int count1 = 0;
		for(int i =0; i < ch.length;i++)
		{
			if(ch[i]=='a' || ch[i]=='e'||      ch[i]=='i' ||  ch[i]=='o' ||  ch[i]=='u' ) {
				count = count +1;
			}
			else if(ch[i] == ' ' || ch[i] == '.' ) {
				continue;
			}
			else {
				count1 = count1 + 1;
			}
		}
			System.out.println("The no of vowels is "+count);
			System.out.println("The no of consonants is "+count1);
			
				
				
			}
		
	}


