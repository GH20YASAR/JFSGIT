package vowels;

import java.util.Scanner;

public class Ascii {
	public static void main(String[] args) {
		Scanner scanner = new Scanner(System.in);
		System.out.println("Enter the number");
		String x = scanner.nextLine();
		String y = x.toLowerCase();
		int count1 = 0 ; 
		int count2 = 0;
		int count3 = 0;
		int count4 = 0 ;
		char find[] = y.toCharArray();
		
		for (int i = 0 ; i <find.length ; i++)
		{
			if(find[i]=='a' || find[i]=='e'||      find[i]=='i' ||  find[i]=='o' ||  find[i]=='u' )
					{
				count1++;
			}
			else if (find[i] >= 32 && find[i] <= 47)
			{
				count2++;
				
			}
			else if (find[i] == ' '   && find[i] == '.')
			{
				continue;
			}
			
			else if (find[i] >= 48 && find[i] <= 57)
			{
			count3++;
			}
			else {
				count4++;
			}
		}
		
		
		System.out.println("the count of vowels is "+count1);
		System.out.println("the count of special characters is "+count2);
		System.out.println("the count of numbers is "+count3);
		System.out.println("the count of consonants  is "+count4);
		
	}

}
