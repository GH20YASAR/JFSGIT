package collections;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

public class GroupEmployeesHashMap {
	public static void main(String[] args) {
		List<Employee> employeeArrayList = new ArrayList<>();
		employeeArrayList.add(new Employee("Rambo", "IT", 500));
		employeeArrayList.add(new Employee("John", "ECE", 500));
		employeeArrayList.add(new Employee("Mary", "IT", 500));
		employeeArrayList.add(new Employee("Rosy", "ECE", 500));
		employeeArrayList.add(new Employee("Rambo", "EEE", 500));

		groupByDepartment(employeeArrayList);
		//groupByDepartmentString(employeeArrayList);
	}
	public static void groupByDepartment(List<Employee> employeeList) {
		Map<String, List<Employee>> departmentAndEmployeesMap = new HashMap<>();
		for (Employee employee : employeeList) {
			if(departmentAndEmployeesMap.get(employee.department) == null) {
				List<Employee> departmentList = new ArrayList<>();
				departmentList.add(employee);
				departmentAndEmployeesMap.put(employee.department, departmentList);
			}
			else {
				List<Employee> departmentList = departmentAndEmployeesMap.get(employee.department);
				departmentList.add(employee);
			//	departmentAndEmployeesMap.put(employee.department, departmentList);
			}
		}
//		System.out.println(departmentAndEmployeesMap);
		departmentAndEmployeesMap.forEach((key,value) -> {System.out.println(" Key = " + key + " value = " + value);});
	}
	public static void groupByDepartmentString(List<Employee> employeeList) {
		Map<String, String> departmentAndEmployeesMap = new HashMap<>();
		for (Employee employee : employeeList) {
			if(departmentAndEmployeesMap.get(employee.department) == null) {
				departmentAndEmployeesMap.put(employee.department, employee.toString());
			}
			else {
				String employeeString = departmentAndEmployeesMap.get(employee.department);
				departmentAndEmployeesMap.put(employee.department,  employeeString+ "\n" + employee.toString());
			}
		}
//		System.out.println(departmentAndEmployeesMap);
		departmentAndEmployeesMap.forEach((key,value) -> {System.out.println(" Key = " + key + " value = " + value);});
	}
}

class Employee {
	String name;
	String department;
	int salary;

	public Employee(String name, String department, int salary) {
		super();
		this.name = name;
		this.department = department;
		this.salary = salary;
	}

	@Override
	public String toString() {
		return "\nEmployee [name=" + name + ", department=" + department + ", salary=" + salary + "\n]";
	}
	
	

	
	
}