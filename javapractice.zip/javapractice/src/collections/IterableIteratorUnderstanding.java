package collections;

public class IterableIteratorUnderstanding {
	public static void main(String[] args) {
		List1 list1 = new ArrayList1();
		Iterator1 iterator1 = list1.iterator();
		if (iterator1.hasNext()) {
			System.out.println(iterator1.next());
		}
	}
}

interface Iterable1 {
	public Iterator1 iterator();
}

interface Iterator1 {
	public boolean hasNext();

	public String next();
}

interface List1 extends Iterable1 {

}

class ArrayList1 implements List1 {

	@Override
	public Iterator1 iterator() {
		return new Itr1();
	}

	private class Itr1 implements Iterator1 {

		@Override
		public boolean hasNext() {
			return true;
		}

		@Override
		public String next() {
			// TODO Auto-generated method stub
			return "element";
		}

	}
}