package collections;

import java.util.Iterator;
import java.util.List;
import java.util.ListIterator;
import java.util.PriorityQueue;
import java.util.Queue;
import java.util.Vector;

public class ListIteratorEx {
	public static void main(String[] args) {
//		testIterator();
		testListIterator();
	}

	private static void testIterator() {
		Queue<Integer> queue = new PriorityQueue<>();
		queue.add(100);
		queue.add(200);
		queue.add(100);
		queue.add(200);
		queue.add(100);
		System.out.println(queue);
		Iterator iterator = queue.iterator();
		while (iterator.hasNext()) {
			if ((Integer) iterator.next() == 100) {
				iterator.remove();
			}
//			System.out.println(iterator.next());
		}
		System.out.println(queue);
	}

	private static void testListIterator() {
		List<Integer> list = new Vector<>();
		list.add(100);
		list.add(200);
		list.add(100);
		list.add(200);
		list.add(100);
		System.out.println(list);
		ListIterator iterator = list.listIterator();
		while (iterator.hasNext()) {
			if ((Integer) iterator.next() == 100) {
				iterator.remove();
				iterator.add(2000);
			}
//			System.out.println(iterator.next());
		}
		System.out.println();
	}
}