package java8;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ArrayListSortMethod {
	public static void main(String[] args) {
		TestDTO testDTO = new TestDTO("Sita");
		TestDTO testDTO1 = new TestDTO("Rama");
		List<TestDTO> namesList = new ArrayList<TestDTO>();
		namesList.add(testDTO);
		namesList.add(testDTO1);
		System.out.println(namesList);
		Comparator<TestDTO> lambdaComparator = ( testDTO4,  testDTO5) -> testDTO4.name.compareTo(testDTO5.name);
		namesList.sort(lambdaComparator);	
//		namesList.sort((TestDTO testDTO4, TestDTO testDTO5) -> testDTO4.name.compareTo(testDTO5.name));
		namesList.sort(( testDTO4,  testDTO5) -> testDTO4.name.compareTo(testDTO5.name));	
		System.out.println(namesList);
	}
}

//list.sort(new Comparator<TestDTO>() {
//    @Override
//    public int compare(TestDTO o1, TestDTO o2) {
//        return o1.name.compareTo(o2.name);
//    }
//});

class TestDTO {
	String name;

	public TestDTO(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "TestDTO [name=" + name + "]";
	}
}