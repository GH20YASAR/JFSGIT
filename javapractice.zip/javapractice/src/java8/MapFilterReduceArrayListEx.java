package java8;

import java.util.ArrayList;
import java.util.stream.Stream;

 public class MapFilterReduceArrayListEx{
	public static void main(String[] args) {
		mappingOperation1();
		filter_operation();
		reduction_operation();
	}

private static void mappingOperation1()
{
	 System.out.println("Doing Mapping Operations");
        
   ArrayList<String>players = new ArrayList<String>();
   players.add("sam");
   players.add("lilly");
   players.add("peter");
   players.add("ram");
   


Stream<String> stream = players.stream();
      
        Stream<String> upperCaseStream = stream.map((String player) -> player.toUpperCase());
       
        upperCaseStream.forEach(System.out::println);        
}

private static void filter_operation() {
	
	 System.out.println("Doing Filtering Operations");
	ArrayList<String>players= new ArrayList<String>();
	  players.add("sam");
	   players.add("lilly");
	   players.add("peter");
	   players.add("ram");
	   
    Stream<String> stream = players.stream();

    Stream<String> filteredStream = stream.filter(player -> player.length() > 3);

    filteredStream.forEach(System.out::println);        
}

private static void reduction_operation() {
	// A simple array

	 System.out.println("Doing Filtering Operations");
	ArrayList<Integer>no= new ArrayList<Integer>();
	  no.add(7000);
	   no.add(100);
	   no.add(200);
	   Stream<Integer> stream = no.stream();
	   Integer yasar = stream. reduce(1,(a,i) -> a*i);
	   
	   
	   
	   System.out.println(yasar);
//		Object[] noArray =	no.toArray();
//		System.out.println(Arrays.stream(noArray).sum());s

}

 }





