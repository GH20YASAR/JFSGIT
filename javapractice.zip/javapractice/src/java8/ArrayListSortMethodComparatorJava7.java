package java8;

import java.util.ArrayList;
import java.util.Comparator;
import java.util.List;

public class ArrayListSortMethodComparatorJava7 {
	public static void main(String[] args) {
		//charComparison();
		useAnonymousComparator();
	
	}
	private static void charComparison() {
		int charVal = 'a';
		int charVal1 = 'c';
		System.out.println(charVal);
		System.out.println(charVal1);
		System.out.println(charVal-charVal1);
	}
	private static void useAnonymousComparator() {
		TestDTO1 testDTO = new TestDTO1("Sita");
		TestDTO1 testDTO1 = new TestDTO1("Rama");
		TestDTO1 testDTO2 = new TestDTO1("Anu");
		TestDTO1 testDTO3 = new TestDTO1("Nelson");
		List<TestDTO1> namesList = new ArrayList<TestDTO1>();
		namesList.add(testDTO);
		namesList.add(testDTO1);
		namesList.add(testDTO2);
		namesList.add(testDTO3);
		System.out.println(namesList);
		// anonymous class
		Comparator<TestDTO1> customComparator1 = new Comparator<TestDTO1>() {
			@Override
			public int compare(TestDTO1 testDTO1, TestDTO1 testDTO2) {
				return testDTO2.name.compareTo(testDTO1.name);
			}
		};
		namesList.sort(customComparator1);
		System.out.println(namesList);
	}
	private static void useCustomComparator() {
		TestDTO1 testDTO = new TestDTO1("Sita");
		TestDTO1 testDTO1 = new TestDTO1("Rama");
		TestDTO1 testDTO2 = new TestDTO1("Anu");
		TestDTO1 testDTO3 = new TestDTO1("Nelson");
		List<TestDTO1> namesList = new ArrayList<TestDTO1>();
		namesList.add(testDTO);
		namesList.add(testDTO1);
		namesList.add(testDTO2);
		namesList.add(testDTO3);
		System.out.println(namesList);

		CustomComparator customComparator = new CustomComparator();
		namesList.sort(customComparator);
		System.out.println(namesList);
	}
}

class CustomComparator implements Comparator<TestDTO1> {

	@Override
	public int compare(TestDTO1 testDTO1, TestDTO1 testDTO12) {
		return testDTO1.name.compareTo(testDTO12.name);
	}

}
//list.sort(new Comparator<TestDTO>() {
//    @Override
//    public int compare(TestDTO o1, TestDTO o2) {
//        return o1.name.compareTo(o2.name);
//    }
//});

class TestDTO1 {
	String name;

	public TestDTO1(String name) {
		this.name = name;
	}

	@Override
	public String toString() {
		return "TestDTO [name=" + name + "]";
	}
}