package multithreading;


import java.util.Scanner;
public class SampleThreadProgramEx{


public static void main(String[] args) {

		ListThread listThread = new ListThread();
		listThread.start();
		ProductThread1 productThread = new ProductThread1();
		productThread.start();
	}

}

class List {

	String color;

	public List(String Ccolor) {
		color = Ccolor;
	}

	public void display() {
		System.out.println(color);

	}
}

class ProductName {
	String Pname;

	ProductName(String Pname) {
		this.Pname = Pname;
	}

	public void display() {
		System.out.println(Pname);

	}

}

class ListThread extends Thread {
	public void run() {
		Scanner s = new Scanner(System.in);
		System.out.println("Enter colornames");
		String c1 = s.nextLine();
		String c2 = s.nextLine();
		String c3 = s.nextLine();
		String c4 = s.nextLine();
		String c5 = s.nextLine();
		List c11 = new List(c1);
		List c12 = new List(c2);
		List c13 = new List(c3);
		List c14 = new List(c4);
		List c15 = new List(c5);
		c11.display();
		c12.display();
		c13.display();
		c14.display();
		c15.display();
		
	
	}
}

class ProductThread1 extends Thread {
	public void run() {
		try {
			sleep(20000);
		} catch (InterruptedException e) {
			System.out.println(e);
		}
		Scanner s = new Scanner(System.in);
		System.out.println("Enter Productname");
		String p1 = s.nextLine();
		String p2 = s.nextLine();
		String p3 = s.nextLine();
		String p4 = s.nextLine();
		ProductName p11 = new ProductName(p1);
		ProductName p12 = new ProductName(p2);
		ProductName p13 = new ProductName(p3);
		ProductName p14 = new ProductName(p4);
		p11.display();
		p12.display();
		p13.display();
		p14.display();
		
	}
}