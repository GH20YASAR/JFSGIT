package multithreading;

public class EvenOddThreads  {
	// THE MAIN THREAD
	public static void main(String[] args) {
		
		String mainthreadname = Thread.currentThread().getName();
		System.out.println(mainthreadname +"thread");
		
		
		//CREATE THE EVEN THREAD
		EvenThread evenThread = new EvenThread();
	evenThread.setName("evenThreads");
		String evenThreadName = evenThread.getName();
	System.out.println(evenThreadName +"thread");
		evenThread.start();
		
		OddThread oddThread = new OddThread();
	oddThread.setName("oddThreads");
	String oddThreadName = oddThread.getName();
		System.out.println(oddThreadName +"thread");
		oddThread.start();
		
	}

}
class EvenThread extends Thread {
	public void run() {
		for(int i= 0; i<100 ; i=i+2)
		{
			System.out.println(i);
		}
	}
}



class OddThread extends Thread {
	public void run() {
		for(int i= 1; i<100 ; i=i+2)
		{
			System.out.println(i);
		}
	}
		
	}
