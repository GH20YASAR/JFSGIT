package basic;

public class StaticObjectEx {
	public static void main(String[] args) {
		System.out.println(Learner.meetingPlatform);
		Learner.getPlatform();
		
		Learner yasar = new Learner();
		yasar.name = "Yasar";
		Learner arafath = new Learner();
		arafath.name = "Arafath";
		
		yasar.getName();
		arafath.getName();
		
	}

}

class Learner
{
	//static and belongs to the class
	public static String meetingPlatform = "Webex";
	public static void getPlatform() {
		System.out.println(meetingPlatform);
	}
	 //instance variable and 
public String name;
public void getName() {
	System.out.println(name);
}

	
}
