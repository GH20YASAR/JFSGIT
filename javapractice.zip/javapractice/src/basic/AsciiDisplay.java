package basic;

import java.util.Map;
import java.util.Map.Entry;
import java.util.Set;
import java.util.TreeMap;

public class AsciiDisplay {
	public static void main(String[] args) {
		decimalToChar();
		smallToCapital();
		test();
	}

	private static void decimalToChar() {
		for (int decimal = 97; decimal <= 122; decimal++) {
			char small = (char) decimal;
			char capital = (char) (decimal - 32);
			System.out.println(small + " > " + capital);
		}
	}

	private static void smallToCapital() {
		for (int decimal = 97; decimal <= 122; decimal++) {
			char decimalToChar = (char) decimal;
			System.out.println(decimal + " > " + decimalToChar);
		}
	}

	private static void test() {
//		- JAva Output - A-2, J-1, V-1
		String testString = "JAva Programming";
		System.out.println(testString);
		testString = testString.replaceAll("\\s", "");
		System.out.println(testString);
		Map<Character, Integer> map = new TreeMap<>();
		for (int i = 0; i < testString.length(); i++) {
			Character testCharacter = testString.charAt(i);
			testCharacter = Character.toUpperCase(testCharacter);
			if (map.get(testCharacter) == null) {
				map.put(testCharacter, 1);
			} else {
//				Auto Unboxing (Wrapper to Primitive)
				int countInteger = map.get(testCharacter);
//			Auto Boxing (Primitive to Wrapper)
				map.put(testCharacter, ++countInteger);
			}
		}
		System.out.println(map);
		
//		String outputString = map.toString();
//		outputString = outputString.substring(1,outputString.length()-1);
//		System.out.println(outputString);
//		//System.out.println(map);
		
		
		
		String outputString = "";
		Set<Entry<Character, Integer>> entrySet = map.entrySet();
		for (Entry<Character, Integer> entry : entrySet) {
			outputString = outputString + entry.getKey() + "-" + entry.getValue() + ", ";
		}

		//System.out.println(outputString);
		outputString = outputString.substring(0, outputString.length()-2);
		System.out.println(outputString);
	}
}