package com.fmcg;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class P4EurekaMicroserviceApplicationTests {

	@Test
	void contextLoads() {
	}

}
