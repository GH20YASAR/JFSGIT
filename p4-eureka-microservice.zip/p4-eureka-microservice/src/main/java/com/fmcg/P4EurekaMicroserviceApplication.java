package com.fmcg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.netflix.eureka.server.EnableEurekaServer;
@EnableEurekaServer
@SpringBootApplication
public class P4EurekaMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(P4EurekaMicroserviceApplication.class, args);
	}

}
