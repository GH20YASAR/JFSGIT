package com.fmcg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JacksonInject.Value;


import com.fmcg.repository.OrderRepository;
import com.fmcg.entity.Order;
import com.fmcg.entity.OrdersResponse;

@RestController
@RequestMapping("/api")
public class OrderController {
	@Autowired
	OrderRepository orderRepository;

	

	
	
	@GetMapping("/orders")
	protected List<Order> getAllOrders()  {
		List<Order> ordersList = orderRepository.findAll();
		return ordersList;
	}
	
	@GetMapping("/orders/response")
	private OrdersResponse getAllOrdersResponse() {
		List<Order> ordersList = orderRepository.findAll();
		OrdersResponse ordersResponse = new OrdersResponse();
		ordersResponse.setOrders(ordersList);
		return ordersResponse;
	}

 //SEARCH
	@GetMapping("/orders/find/{shippingAddress}")
	public List<Order> searchProductByName(@PathVariable(value="shippingAddress") String shippingAddress){
	List<Order>  ordersList = orderRepository.findByShippingAddress(shippingAddress);
		return ordersList;
	}
	@PostMapping("/orders")
	private Order insertOrder(@RequestBody Order orderFromBrowser) {
		Order savedOrder =orderRepository.save(orderFromBrowser);
		return savedOrder;
		
	}
	@PutMapping("/orders/{id}")
	private Order updateOrder(@PathVariable(value = "id")String orderId,@RequestBody Order orderFromBrowser)
	{
		Order existingOrder = orderRepository.findById(orderId).get();
		existingOrder.setProductId(orderFromBrowser.getProductId());
		existingOrder.setQuantity(orderFromBrowser.getQuantity());
		Order updatedOrder = orderRepository.save(existingOrder);
		return updatedOrder;
		
	}
		
		@DeleteMapping("/orders/{orderIdForBrowser}")
		private void deleteOrder(@PathVariable (value ="orderIdForBrowser")String orderId)
		{
			orderRepository.deleteById(orderId)	;
		}
		
	}
	


	