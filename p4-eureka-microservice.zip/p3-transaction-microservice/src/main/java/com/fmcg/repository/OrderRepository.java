package com.fmcg.repository;
import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import org.springframework.web.bind.annotation.PathVariable;

import com.fmcg.entity.Order;


@Repository
public interface OrderRepository extends JpaRepository<Order, String>{


	@Query("Select order from Order order where order.shippingAddress = :shippingAddress")
	public List<Order> findByShippingAddress(@Param("shippingAddress")String shippingAddress);
		
	
	
}
