package com.fmcg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "Orders")
public class Order{
	@Id
	@Column(name = "ORDER_ID")
	private String orderId;
	
	@Column(name = "USER_ID")
	private String userId;
	@Column(name = "PRODUCT_ID")
	private String productId;
	
	private int quantity;
	@Column(name = "ORDER_DATE")
    private String orderDate;
    @Column(name = "SHIPPING_ADDRESS")
    private String shippingAddress;
    @Column(name = "SHIPPED_DATE")
    private String shippedDate;
    
	
	
	
	public Order() {

	}
	
	
	public Order(String orderId,String UserId, String productId,int quantity,String orderDate ,String shippingAddress, String shippedDate) 
	
	{
	this. orderId =  orderId;
	this.userId = userId;
	
	this. productId = productId;
	this.quantity = quantity;
	
	this. orderDate = orderDate;
	this.shippingAddress = shippingAddress;
	this.shippedDate = shippedDate;
	}


	public String getOrderId() {
		return orderId;
	}


	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}


	public String getUserId() {
		return userId;
	}


	public void setUserId(String userId) {
		this.userId = userId;
	}


	public String getProductId() {
		return productId;
	}


	public void setProductId(String productId) {
		this.productId = productId;
	}


	public int getQuantity() {
		return quantity;
	}


	public void setQuantity(int quantity) {
		this.quantity = quantity;
	}


	public String getOrderDate() {
		return orderDate;
	}


	public void setOrderDate(String orderDate) {
		this.orderDate = orderDate;
	}


	public String getShippingAddress() {
		return shippingAddress;
	}


	public void setShippingAddress(String shippingAddress) {
		this.shippingAddress = shippingAddress;
	}


	public String getShippedDate() {
		return shippedDate;
	}


	public void setShippedDate(String shippedDate) {
		this.shippedDate = shippedDate;
	}


	@Override
	public String toString() {
		return "Order [orderId=" + orderId + ", userId=" + userId + ", productId=" + productId + ", quantity="
				+ quantity + ", orderDate=" + orderDate + ", shippingAddress=" + shippingAddress + ", shippedDate="
				+ shippedDate + "]";
	}
	
}

	
	
	
	
	

