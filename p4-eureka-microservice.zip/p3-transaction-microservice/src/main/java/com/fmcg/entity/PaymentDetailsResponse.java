package com.fmcg.entity;

import java.util.List;

public class PaymentDetailsResponse {
	private List<PaymentDetail> paymentDetails;

	public List<PaymentDetail> getPaymentDetails() {
		return paymentDetails;
	}
	public void setPaymentDetails(List<PaymentDetail> paymentDetails) {
		this.paymentDetails = paymentDetails;
	}

}