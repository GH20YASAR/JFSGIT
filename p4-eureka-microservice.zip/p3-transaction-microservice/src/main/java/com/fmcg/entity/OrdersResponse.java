package com.fmcg.entity;

import java.util.List;

public class OrdersResponse {
	private List<Order> orders;

	public List<Order> getOrders() {
		return orders;
	}
	public void setOrders(List<Order> orders) {
		this.orders = orders;
	}

}