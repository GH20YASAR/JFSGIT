package com.bank.entity;

public class UsersResponse {

}
