package com.bank.entity;

import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;
import javax.persistence.Column;




@Entity
@Table(name = "Accounts")
public class Accounts {
	@Id
	@Column(name ="ACCOUNT_NUMBER")
	private long accountNumber;
	@Column(name = "USERNAME")
	private String userName;
	@Column (name = "ACCOUNT_BALANCE")
	private float accountBalance;
	


public Accounts(long accountNumber,String userName ,float accountBalance)
{
	this.accountNumber = accountNumber;
	this.userName = userName;
	this.accountBalance = accountBalance;
}




public Accounts() {
	
}

public void setAccountNo(long accountNo) {
	this.accountNumber = accountNo;
}



public void setUserName(String userName) {
	this.userName = userName;
}



public void setAccountBalance(float accountBalance) {
	this.accountBalance = accountBalance;
}



public long getAccountNo() {
	return accountNumber;
}



public String getUserName() {
	return userName;
}



public float getAccountBalance() {
	return accountBalance;
}



@Override
public String toString() {
	return "accountNo =  " + accountNumber + "   userName =  " + userName + "    accountBalance =" + accountBalance ;
}
}
