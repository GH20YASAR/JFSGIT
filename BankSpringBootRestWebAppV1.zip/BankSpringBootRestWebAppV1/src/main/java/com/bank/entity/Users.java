package com.bank.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name ="USERS" )
public class Users {
	
	@Id
	@Column(name = "USERNAME")
	private String userName;
	private String password;
	private String creationDate;
	private int noOfAccounts;
	private long listOfAccountNumbers;
	private float totalBalance;
	private long contactNo;
	
	
	
	public Users() {
	
	}
	


public Users(String userName,String password ,String  creationDate, int noOfAccounts,long listOfAccountNumbers,float totalBalance,long contactNumber)
{
	this.userName = userName;
	this.password = password;
	this.creationDate = creationDate;
	this.noOfAccounts = noOfAccounts;
	this.listOfAccountNumbers = listOfAccountNumbers;
	this.totalBalance = totalBalance;
	this.contactNo= contactNumber;
}





public String getUserName() {
	return userName;
}





public String getPassword() {
	return password;
}





public String getCreationDate() {
	return creationDate;
}





public int getNoOfAccounts() {
	return noOfAccounts;
}





public long getListOFAccountNumbers() {
	return listOfAccountNumbers;
}





public float getTotalBalance() {
	return totalBalance;
}





public long getContactNumber() {
	return contactNo;
}





@Override
public String toString() {
	return "userName=  " + userName + " password=  " + password + " creationDate=  " + creationDate
			+ " noOfAccounts=  " + noOfAccounts + " listOfAccountNumbers=   " + listOfAccountNumbers + " totalBalance=   "
			+ totalBalance + " contactNumber=  " + contactNo ;
}





public long getListOfAccountNumbers() {
	return listOfAccountNumbers;
}





public void setListOfAccountNumbers(long listOfAccountNumbers) {
	this.listOfAccountNumbers = listOfAccountNumbers;
}





public long getContactNo() {
	return contactNo;
}





public void setContactNo(long contactNo) {
	this.contactNo = contactNo;
}





public void setUserName(String userName) {
	this.userName = userName;
}





public void setPassword(String password) {
	this.password = password;
}





public void setCreationDate(String creationDate) {
	this.creationDate = creationDate;
}





public void setNoOfAccounts(int noOfAccounts) {
	this.noOfAccounts = noOfAccounts;
}





public void setTotalBalance(float totalBalance) {
	this.totalBalance = totalBalance;
}
}

