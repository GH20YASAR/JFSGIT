package com.bank.entity;

import java.util.List;

import com.bank.entity.Accounts;

public class AccountsResponse {
	private List<Accounts> accounts;

	public List<Accounts> getAccounts() {
		return accounts;
	}
	public void setProducts(List<Accounts> accounts) {
		this.accounts = accounts;
	}

}