package com.bank;
import org.springframework.web.client.RestTemplate;

import com.bank.entity.Accounts;
import com.bank.entity.AccountsResponse;




	public final class BankSpringBootRestApp {
		final static RestTemplate productsRestTemplate;
		final static String restAPIURLString = "http://localhost:9091/bank/api/accounts/";
//static block
		static {
			productsRestTemplate = new RestTemplate();
		}

		public static void main(String[] args) {
			System.out.println("FmcgGlobalDesktopSpringRESTApp");
			getAllAccounts();
			saveAccounts();
			updateAccounts();
			deleteAccounts();
		}

		private static void getAllAccounts() {
			AccountsResponse accountsResponse = productsRestTemplate.getForObject(restAPIURLString + "response",
					AccountsResponse.class);
			accountsResponse.getAccounts().forEach(System.out::println);
		}
		
		private static void saveAccounts() {
			Accounts accounts = new Accounts(12232373513l,"Rahul",5000);
			Accounts createdAccount = productsRestTemplate.postForObject(restAPIURLString, accounts,
					Accounts.class);
			System.out.println("\n\n***** SAVED PRODUCT ******" + createdAccount);
		}

		private static void updateAccounts() {
			Accounts accounts = new Accounts(12232373513l,"karnan",5000);
			productsRestTemplate.put(restAPIURLString + accounts.getAccountNo(), accounts);
		}
		private static void deleteAccounts() {
			String accountNoString = "12232387634";
			productsRestTemplate.delete(restAPIURLString + accountNoString);
		}
	}
	

