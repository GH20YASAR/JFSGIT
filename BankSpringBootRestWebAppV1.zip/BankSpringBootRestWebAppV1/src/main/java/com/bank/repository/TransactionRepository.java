package com.bank.repository;



import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;


import com.bank.entity.Transactions;
import com.bank.entity.Accounts;


@Repository
public interface TransactionRepository extends JpaRepository<Transactions,String> {
	
	
//	@Query("Select * from Accounts accounts where accounts.accountBalance >= :amountParam and accounts.accountNumber = :accountNoParam")
//	public List<Accounts> validateBalance(@Param("accountNoParam")long accountNo,@Param ("amountParam")float amount);
//	
//	
//	
//	@Query("update Accounts accounts set accounts.accountBalance = (accounts.accountBalance - :amountParam) where accountNumber = :accountNoParam")
//			public void update1(@Param("accountNoParam")long accountNo,@Param ("amountParam")float amount );
//	
//	
//	@Query("update Accounts accounts set accounts.accountBalance = (accounts.accountBalance + :amountParam) where accountNumber = :accountNoParam")
//	public void update2(@Param("accountNoParam")long accountNo,@Param ("amountParam")float amount );

	
}
