package com.bank.controller;

import java.util.List;
import java.util.Optional;

import javax.persistence.criteria.From;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bank.entity.Accounts;
import com.bank.entity.Transactions;
import com.bank.repository.AccountRepository;
import com.bank.repository.TransactionRepository;






@RestController
@RequestMapping("/api")
public class TransactionController {
	@Autowired
	TransactionRepository transactionRepository ;
	@Autowired
	AccountRepository accountRepository;
	

	
	
	
	@GetMapping("/displayTransactions")
	protected String displayAllTransactions()
	{
		
		List<Transactions> transactionsList = transactionRepository.findAll();
		String transactionsHTML = "<html><head><title>Display Account Details !!!</title>"
				+ "<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css\">\r\n" + 
				"    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js\"></script>\r\n" + 
				"    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js\"></script>\r\n" + 
				"    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js\"></script></head><body><h1>Accounts List</h1>";
		transactionsHTML += 	"<table class=\"table table-dark table-striped\" style = \"width:500px\"><tr><th>Transaction_ID</th><th>From_Account</th><th>To_Account</th><th>Amount</th></tr>";
	
		for(Transactions transactions :transactionsList) {
			transactionsHTML +=	"<tr><td>"+transactions.getTransactionId() +"</td><td>"+ transactions.getFromAccount()+"</td><td>"+ transactions.getToAccount()+ "</td><td>" + transactions.getAmount()+ "</td></tr>";
		}
		transactionsHTML +=	 "</table></body></html>";
		System.out.println(transactionsHTML);
		return transactionsHTML;
	}
	
	

	@GetMapping("/transactions")
	protected List<Transactions> getAllProducts()  {
		List<Transactions> transactionsList = transactionRepository.findAll();
		return transactionsList;
	}
	
	
	@PostMapping("/transferamount")
	  private void transferAmount(@RequestBody Transactions transactionsFromBrowser) {
		
		
		    float transactionAmount = transactionsFromBrowser.getAmount();
		   long  fromAccount = transactionsFromBrowser.getFromAccount();
		   long toAccount =transactionsFromBrowser.getToAccount();
		
		  Accounts fromActualAccount =  accountRepository.findById(fromAccount).get();
		   float actualBalanceFromAccount =  fromActualAccount.getAccountBalance();
		  
		   

			  Accounts toActualAccount =  accountRepository.findById(toAccount).get();
			   float actualBalanceToAccount =  toActualAccount.getAccountBalance();
			  
			
				
		if(transactionAmount <= actualBalanceFromAccount)
		{
			fromActualAccount.setAccountBalance(actualBalanceFromAccount-transactionAmount);
			toActualAccount.setAccountBalance(actualBalanceToAccount+transactionAmount);
			accountRepository.save(fromActualAccount);
			accountRepository.save(toActualAccount);
		  transactionRepository.save(transactionsFromBrowser);
		  
		  
		  System.out.println("Amount Transfered Successfully");
		
		}
		else
		{
			System.out.println("Insufficient balance");
		}
		
		
		
	}
	
}