package com.bank.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bank.entity.Accounts;
import com.bank.entity.AccountsResponse;
import com.bank.repository.AccountRepository;




@CrossOrigin(origins = "http://localhost:4200")
@RestController
@RequestMapping("/api")
public class AccountController {
	@Autowired
	AccountRepository accountRepository ;

	
	
	@GetMapping("/displayAccounts")
	protected String displayAllAccounts()
	{
		
		List<Accounts> accountList = accountRepository.findAll();
		String accountsHTML = "<html><head><title>Display Account Details !!!</title>"
				+ "<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css\">\r\n" + 
				"    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js\"></script>\r\n" + 
				"    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js\"></script>\r\n" + 
				"    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js\"></script></head><body><h1>Accounts List</h1>";
		accountsHTML += 	"<table class=\"table table-dark table-striped\" style = \"width:500px\"><tr><th>Account_Number</th><th>UserName</th><th>Account_Balance</th></tr>";
	
		for(Accounts accounts : accountList) {
			accountsHTML +=	"<tr><td>"+accounts.getAccountNo() +"</td><td>"+ accounts.getUserName()+"</td><td>"+ accounts.getAccountBalance()+ "</td></tr>";
		}
		accountsHTML +=	 "</table></body></html>";
		System.out.println(accountsHTML);
		return accountsHTML;
	}
	
	@GetMapping("/accounts")
	protected List<Accounts> getAllProducts()  {
		List<Accounts> accountsList = accountRepository.findAll();
		return accountsList;
		
	}
	
	
	@GetMapping("/accounts/response")
	private AccountsResponse getAllAccountsResponse() {
		List<Accounts> accountsList = accountRepository.findAll();
		AccountsResponse accountsResponse = new AccountsResponse();
		accountsResponse.setProducts(accountsList);
		return accountsResponse;
	}

	
	// SEARCH PRODUCTS BY ACCOUNT NAME
	@GetMapping("/accounts/find/{accountName}")
	public List<Accounts> searchAccountByName(@PathVariable(value="accountName") String accountName){
		List<Accounts>  accountsList = accountRepository.findByUserName(accountName);
		return accountsList;
	}
	
	
	
	 
	
	@PostMapping("/accounts")
	private Accounts insertProduct(@RequestBody Accounts accountFromBrowser) {
		Accounts savedAccount = accountRepository.save(accountFromBrowser);
		return savedAccount;

	}
	
	
	@PutMapping("/accounts/{no}")
	private Accounts updateAccounts(@PathVariable(value = "no")	Long accountNo,@RequestBody Accounts accountsFromBrowser)
	{
		Accounts existingAccounts = accountRepository.findById(accountNo).get();
		existingAccounts.setUserName(accountsFromBrowser.getUserName());
	
		Accounts updatedAccount = accountRepository.save(existingAccounts);
		return updatedAccount;
		
	}
	
	@DeleteMapping("/accounts/{no}")
	private void deleteProduct(@PathVariable(value ="no") Long accountNo)
	{
		accountRepository.deleteById(accountNo)	;
	}
	
}


		
