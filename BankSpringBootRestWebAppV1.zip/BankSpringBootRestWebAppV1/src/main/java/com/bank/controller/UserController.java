package com.bank.controller;

import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.bank.entity.Accounts;
import com.bank.entity.Users;
import com.bank.repository.UserRepository;




@RestController
@RequestMapping("/api")
public class UserController {
	@Autowired
	UserRepository userRepository ;
	
	
	
	@GetMapping("/displayUsers")
	protected String displayAllUsers()
	{
		
		List<Users> usersList = userRepository.findAll();
		String usersHTML = "<html><head><title>Display Account Details !!!</title>"
				+ "<link rel=\"stylesheet\" href=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css\">\r\n" + 
				"    <script src=\"https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js\"></script>\r\n" + 
				"    <script src=\"https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js\"></script>\r\n" + 
				"    <script src=\"https://maxcdn.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js\"></script></head><body><h1>Accounts List</h1>";
		usersHTML += 	"<table class=\"table table-dark table-striped\" style = \"width:500px\"><tr><th>UserName</th><th>Password</th><th>CreationDate</th><th>No Of Accounts</th><th>List of AccountNumbers</th><th>TotalBalance</th><th>ContactNo</th></tr>";
	
		for(Users users :usersList) {
			usersHTML +=	"<tr><td>"+users.getUserName() +"</td><td>"+ users.getPassword()+"</td><td>"+ users.getCreationDate()+ "</td><td>" + users.getNoOfAccounts()+ "</td><td>" + users.getListOfAccountNumbers()+"</td><td>" + users.getTotalBalance()+"</td><td>" + users.getContactNo()+"</td></tr>";		
			}
		usersHTML +=	 "</table></body></html>";
		System.out.println(usersHTML);
		return usersHTML;
	}
	
	@GetMapping("/users")
	protected List<Users> getAllProducts()  {
		List<Users> usersList = userRepository.findAll();
		return usersList;
	}
	
	
	@GetMapping("/users/find/{contactNo}")
	public List<Users> searchAccountByName(@PathVariable Long contactNo){
		List<Users>  usersList = userRepository.findByContactNo(contactNo);
		return usersList;
	}
	

	@PostMapping("/insertuser")
	private Users insertUsers(@RequestBody Users usersFromBrowser) {
		Users savedUsers = userRepository.save(usersFromBrowser);
		return savedUsers;

	}
	
	
	@PutMapping("/updateuser/{name}")
	private Users updateUsers(@PathVariable(value = "name")	String userName,@RequestBody Users usersFromBrowser)
	{
		Users existingUsers = userRepository.findById(userName).get();
		existingUsers.setPassword(usersFromBrowser.getPassword());
	
		Users updatedUser = userRepository.save(existingUsers);
		return updatedUser;
		
	}
	
	@DeleteMapping("/deleteuser/{name}")
	private void deleteUsers(@PathVariable(value ="name") String userName)
	{
		userRepository.deleteById(userName)	;
	}
	
}


