package com.bank;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class BankSpringBootWebAppV1 {
	public static void main(String[] args) {
		SpringApplication.run(BankSpringBootWebAppV1.class,args);
		System.out.println("--------------------");
		
	}

}
