package com.fmcg.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import com.fasterxml.jackson.annotation.JacksonInject.Value;



import com.fmcg.repository.PaymentDetailRepository;
import com.fmcg.entity.PaymentDetail;
import com.fmcg.entity.PaymentDetailsResponse;

@RestController
@RequestMapping("/api")
public class PaymentDetailController {
	@Autowired
	PaymentDetailRepository paymentDetailRepository;

	

	
	
	@GetMapping("/paymentdetails")
	protected List<PaymentDetail> getAllPaymentDetails()  {
		List<PaymentDetail> paymentDetailsList = paymentDetailRepository.findAll();
		return paymentDetailsList;
	}
	
	@GetMapping("/paymentdetails/response")
	private PaymentDetailsResponse getAllPaymentDetailsResponse() {
		List<PaymentDetail> paymentDetailsList = paymentDetailRepository.findAll();
		PaymentDetailsResponse paymentDetailsResponse = new PaymentDetailsResponse();
		paymentDetailsResponse.setPaymentDetails(paymentDetailsList);
		return paymentDetailsResponse;
	}

	// SEARCHING
	@GetMapping("/paymentdetails/find/{paymentDateTime}")
	public List<PaymentDetail> searchPaymentDetailsById(@PathVariable(value="paymentDateTime") String paymentDateTime){
		List<PaymentDetail>  paymentDetailsList = paymentDetailRepository.findByPaymentDateTime(paymentDateTime);
		return paymentDetailsList;
	}
	@PostMapping("/paymentdetails")
	private PaymentDetail insertPaymentDetail(@RequestBody PaymentDetail paymentDetailFromBrowser) {
		PaymentDetail savedPaymentDetail =paymentDetailRepository.save(paymentDetailFromBrowser);
		return savedPaymentDetail;
		
	}
	@PutMapping("/paymentdetails/{id}")
	private PaymentDetail updatePaymentDetail(@PathVariable(value = "id")String paymentId,@RequestBody PaymentDetail paymentDetailFromBrowser)
	{
		PaymentDetail existingPaymentDetail = paymentDetailRepository.findById(paymentId).get();
		existingPaymentDetail.setOrderId(paymentDetailFromBrowser.getOrderId());
		existingPaymentDetail.setAmount(paymentDetailFromBrowser.getAmount());
		PaymentDetail updatedPaymentDetail = paymentDetailRepository.save(existingPaymentDetail);
		return updatedPaymentDetail;
		
	}
		
		@DeleteMapping("/paymentdetails/{paymentIdForBrowser}")
		private void deletePaymentDetail(@PathVariable (value ="paymentIdForBrowser")String paymentId)
		{
			paymentDetailRepository.deleteById(paymentId)	;
		}
		
	}
	


	