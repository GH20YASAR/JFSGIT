package com.fmcg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PAYMENT_DETAILS")
public class PaymentDetail{
	@Id
	@Column(name = "PAYMENT_ID")
	private String paymentId;
	
	@Column(name = "ORDER_ID")
	private String orderId;
	
	private float amount;
	@Column(name = "PAYMENT_DATETIME")
	private String paymentDateTime;
	@Column(name = "PAYMENT_TYPE")
    private String paymentType;
   
	
	
	
	public PaymentDetail() {

	}
	
	
	public PaymentDetail(String paymentId,String orderId, float amount,String paymentDateTime,String paymentType) 
	
	{
	this.paymentId =  paymentId;
	this.orderId = orderId;
	
	this. amount = amount;
	this.paymentDateTime = paymentDateTime;
	
	this. paymentType = paymentType;

	}


	public String getPaymentId() {
		return paymentId;
	}


	public void setPaymentId(String paymentId) {
		this.paymentId = paymentId;
	}


	public String getOrderId() {
		return orderId;
	}


	public void setOrderId(String orderId) {
		this.orderId = orderId;
	}


	public float getAmount() {
		return amount;
	}


	public void setAmount(float amount) {
		this.amount = amount;
	}


	public String getPaymentDateTime() {
		return paymentDateTime;
	}


	public void setPaymentDateTime(String paymentDateTime) {
		this.paymentDateTime = paymentDateTime;
	}


	public String getPaymentType() {
		return paymentType;
	}


	public void setPaymentType(String paymentType) {
		this.paymentType = paymentType;
	}


	@Override
	public String toString() {
		return "PaymentDetail [paymentId=" + paymentId + ", orderId=" + orderId + ", amount=" + amount
				+ ", paymentDateTime=" + paymentDateTime + ", paymentType=" + paymentType + "]";
	}
	
	
	
}