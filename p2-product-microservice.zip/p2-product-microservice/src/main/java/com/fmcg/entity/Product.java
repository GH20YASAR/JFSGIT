package com.fmcg.entity;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PRODUCTS")
public class Product {
	@Id
	// productID / PRODUCT_ID
	//@Column(name = "PRODUCT_ID")
	private String productId;
	// productName / PRODUCT_NAME
	//@Column(name = "PRODUCT_NAME")
	private String productName;
	private int price;
	//@Column(name = "AVAILABLE_QUANTITY")
	private int availableQuantity;
    private String expiryDate;
	
	
	
	public Product() {

	}
	
	
	public Product(String productId,String productName, int price,int availableQuantity,String expiryDate ) 
	
	{
	this. productId =  productId;
	this.productName = productName;
	
	this. price = price;
	this.availableQuantity = availableQuantity;
	
	this. expiryDate = expiryDate;
	}

	
	
	
	
	

//	@Override
//	public String toString() {
//		return "Product [productId=" + productId + ", productName=" + productName + ", price=" + price + ", quantity="
//				+ quantity + "]";
//	}

	public String getProductId() {
		return productId;
	}


	public void setProductId(String productId) {
		this.productId = productId;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}





	

	

	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	public int getAvailableQuantity() {
		return availableQuantity;
	}


	public void setAvailabilityQuantity(int availableQuantity) {
		this.availableQuantity = availableQuantity;
	}


	


	public String getExpiryDate() {
		return expiryDate;
	}


	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}


	


	@Override
	public String toString() {
		return "productId=" + productId + " , productName=" + productName  
				+ ", price=" + price + " , availabilityQuantity=" + availableQuantity
				+ "expiryDate=" + expiryDate 
				;
	}
}
