package com.fmcgglobal.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.fmcgglobal.model.Products;

public class ProductRepository {
	public List<Products> findAll() {
		// LIST TO STORE PRODUCTS
		List<Products> productsList = new ArrayList<Products>();
		ResultSet resultSet = MySQLDBConnection.getResultSet("SELECT * FROM PRODUCTS");
		// ITERATE THROUGH THE RESULT SET AND CREATE THE PRODUCT MODEL
		try {
			while (resultSet.next()) {
//				CREATE TABLE PRODUCTS(PRODUCT_ID CHAR(5) PRIMARY KEY NOT NULL,PRODUCT_NAME VARCHAR(20) NOT NULL,SUPPLIER_ID CHAR(5) NOT NULL,CATEGORY_ID CHAR(5) NOT NULL,PRICE INT,AVALIBILITY_QUALITY CHAR(5),REORDER_LEVEL INT ,EXPIRY_DATE DATE,DISCONTINOUED CHAR(5),FOREIGN KEY (SUPPLIER_ID)  REFERENCES SUPPLIERS(SUPPLIER_ID),FOREIGN KEY (CATEGORY_ID) REFERENCES CATEGORIES(CATEGORY_ID));
				String productId = resultSet.getString("PRODUCT_ID");
				String productName = resultSet.getString("PRODUCT_NAME");
				int price = resultSet.getInt("PRICE");
				int availableQuantity = resultSet.getInt("AVAILABLE_QUANTITY");
				String expiryDate = resultSet.getString("EXPIRY_DATE");

				// CREATE A PRODUCT OBJECT FOR THE PRODUCT
				Products product = new Products(productId, productName, price, availableQuantity, expiryDate);
				productsList.add(product);
			}
			return productsList;
		} catch (SQLException sqlException) {
			System.out.println("Problem in Result Set " + sqlException);
		}
		return null;
	}
	
	public List<Products>findAllWithCallableStatement()
	{

			// LIST TO STORE PRODUCTS
			List<Products> productsList = new ArrayList<Products>();
			ResultSet resultSet = MySQLDBConnection.getResultSet("{ call PRC_GET_PRODUCTS ()}");
			// ITERATE THROUGH THE RESULT SET AND CREATE THE PRODUCT MODEL
			try {
				while (resultSet.next()) {
//					CREATE TABLE PRODUCTS(PRODUCT_ID CHAR(5) PRIMARY KEY NOT NULL,PRODUCT_NAME VARCHAR(20) NOT NULL,SUPPLIER_ID CHAR(5) NOT NULL,CATEGORY_ID CHAR(5) NOT NULL,PRICE INT,AVALIBILITY_QUALITY CHAR(5),REORDER_LEVEL INT ,EXPIRY_DATE DATE,DISCONTINOUED CHAR(5),FOREIGN KEY (SUPPLIER_ID)  REFERENCES SUPPLIERS(SUPPLIER_ID),FOREIGN KEY (CATEGORY_ID) REFERENCES CATEGORIES(CATEGORY_ID));
					String productId = resultSet.getString("PRODUCT_ID");
					String productName = resultSet.getString("PRODUCT_NAME");
					int price = resultSet.getInt("PRICE");
					int availableQuantity = resultSet.getInt("AVAILABLE_QUANTITY");
					String expiryDate = resultSet.getString("EXPIRY_DATE");

					// CREATE A PRODUCT OBJECT FOR THE PRODUCT
					Products product = new Products(productId, productName, price, availableQuantity, expiryDate);
					productsList.add(product);
				}
				return productsList;
			} catch (SQLException sqlException) {
				System.out.println("Problem in Result Set " + sqlException);
			}
			return null;
		}
	
	
	
	

	public Products save(Products product) {
		// CREATE THE INSERT QUERY
		String insertQuery = "INSERT INTO PRODUCTS VALUES ('" + product.getProductId() + "','"
				+ product.getProductName() + "'," + product.getPrice() + "," + product.getAvailableQuantity() + ",'"
				+ product.getExpiryDate() + "');";
		System.out.println(insertQuery);

		MySQLDBConnection.saveRecord(insertQuery);
		return product;
	}
	
	
	
	
	

	public void update(Products product) {
		String updateQuery = "UPDATE PRODUCTS SET PRODUCT_NAME = '" + product.getProductName()
				+ "' WHERE PRODUCT_ID = '" + product.getProductId() + "';";
		MySQLDBConnection.updateRecord(updateQuery);

	}

	public void delete(Products product) {
		String deleteQuery = "DELETE FROM PRODUCTS WHERE PRODUCT_ID ='" + product.getProductId() + "';";
		MySQLDBConnection.deleteRecord(deleteQuery);

	}

	public List<Products> filter(Products product) {
		List<Products> productsList1 = new ArrayList<Products>();
		ResultSet resultSet = MySQLDBConnection.getResultSet1("SELECT * FROM PRODUCTS WHERE PRODUCT_ID ='"+product.getProductId()+"';"); 
		// ITERATE THROUGH THE RESULT SET AND CREATE THE PRODUCT MODEL
		try {
			while(resultSet.next()) {
//				CREATE TABLE PRODUCTS(PRODUCT_ID CHAR(5) PRIMARY KEY NOT NULL,PRODUCT_NAME VARCHAR(20) NOT NULL,SUPPLIER_ID CHAR(5) NOT NULL,CATEGORY_ID CHAR(5) NOT NULL,PRICE INT,AVALIBILITY_QUALITY CHAR(5),REORDER_LEVEL INT ,EXPIRY_DATE DATE,DISCONTINOUED CHAR(5),FOREIGN KEY (SUPPLIER_ID)  REFERENCES SUPPLIERS(SUPPLIER_ID),FOREIGN KEY (CATEGORY_ID) REFERENCES CATEGORIES(CATEGORY_ID));
				String productId = resultSet.getString("PRODUCT_ID");
				String productName = resultSet.getString("PRODUCT_NAME");
		        int price = resultSet.getInt("PRICE");
				int availableQuantity = resultSet.getInt("AVAILABLE_QUANTITY");
				String expiryDate = resultSet.getString("EXPIRY_DATE");
				Products product1= new Products(productId,productName,price,availableQuantity,expiryDate);
				productsList1.add(product1);
			}
			return productsList1;
		} catch (SQLException sqlException) {
			System.out.println("Problem in Result Set " + sqlException);
		}
		return null;
	}
}
