package com.fmcgglobal.web;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fmcgglobal.model.Products;
import com.fmcgglobal.repository.ProductRepository;
@WebServlet("/products")
public class ProductServlet extends HttpServlet {
	ProductRepository productRepository = null;
	//Scanner scanner = new Scanner(System.in);

	@Override
public void init() throws ServletException {
		productRepository = new ProductRepository();
		
	}
// HTTP VERBS / SQL STATEMENTS / API
	// GET  / SELECT / findAllProducts
	@Override
	protected void doGet(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

//		Display Products
		PrintWriter printWriter = response.getWriter();
		printWriter.println("<html>");
		printWriter.println("<body> <style>table, th, td {border: 1px solid black;background-color: crimson;padding: 1mm;width:30cm;}</style><h1>Servlets</h1><h2>Displaying all the Products</h2>");
		printWriter.println("<h4 style='color:green'><table><tr><th>Product_ID</th><th>Product_Name</th></th><th>Price</th> <TH>Available_Quantity</TH><th>Expiry_Date</th></tr>");
		List<Products> productsList = productRepository.findAll();
		if (productsList.size() > 0) {
			productsList.forEach(product -> printWriter.println("<tr><td>"+ product.getProductId() +"</td><td>"+ product.getProductName()+"</td><td>"+ product.getPrice()+"</td><td>"+ product.getAvailableQuantity()+"</td><td>"+ product.getExpiryDate()+"</td></tr> </h4>"));
			}
		
		
		
	
	
	//  Update Products
	printWriter.println("</table><form>");
	
	
		
	//String productName  = scanner.nextLine();
//		System.out.println("enter the product Id  where we have to change ProductName :");
////String productId = scanner.nextLine();
//Products product = new Products(productName, productId);
//	productRepository.update(product);
//	printWriter.println("Updated records successfully</form></body></html>");
	
//
//		String productId = "P0002";
//		Products product = new Products(productId);
//		productRepository.delete(product);
//		printWriter.println("<h2>Deleting Products<h2>");
//		printWriter.println("<h2>After Deleting  Displaying Products<h2>");
//		printWriter.println("<h4 style='color:green'><table><tr><th>Product_ID</th><th>Product_Name</th><th>Supplier_ID</th> <th>Category_ID</th><th>Price</th> <TH>Availability_Quantity</TH> <th>Reorder_Level</th> <th>Expiry_Date</th><th>Discontinued</th></tr>");
//		if (productsList.size() > 0) {
//			productsList.forEach(products -> printWriter.println("<tr><td>"+ products.getProductId() +"</td><td>"+ products.getProductName()+"</td><td>"+ products.getSupplierId()+"</td><td>"+ products.getCategoryId()+"</td><td>"+ products.getPrice()+"</td><td>"+ products.getAvailabilityQuantity()+"</td><td>"+ products.getReorderLevel()+"</td><td>"+ products.getExpiryDate()+"</td><td>"+ products.getDiscontinued()+"</td></tr> </h4>"));
//			}
//		printWriter.println("</form></body></html>");
//	}
	

	}
	// POST / INSERT /  save
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
String operationString = request.getParameter("operation");
if(operationString.equals("insert"))
{
		String productId = request.getParameter("productId");
		String productName = request.getParameter("productName");

		int price = Integer.parseInt(request.getParameter("price"));
		int quantityAvailability = Integer.parseInt(request.getParameter("quantityAvailability"));
		
		String expiryDate = request.getParameter("expiryDate");
		
		Products product = new Products(productId, productName, price, quantityAvailability,expiryDate);
		Products savedProduct = productRepository.save(product);
		PrintWriter out = response.getWriter();
		out.println("<html>");
		out.println("<head><script> alert('Product Saved'); </script>");
		out.println("<body><h1>Product Saved</h1>");
		out.println(savedProduct);
		
}
else if(operationString.equals("update"))
{	
		String productIdUpdate = request.getParameter("productId1");
		String productNameUpdate = request.getParameter("productName1");
		Products product1 = new Products(productNameUpdate,productIdUpdate);
		productRepository.update(product1);
		PrintWriter out = response.getWriter();
		out.println("<head><script> alert('Product Updated'); </script>");
		out.println("<body><h1>Product Updated</h1>");
}

		
else if (operationString.equals("delete"))	
{
		String productIdDelete = request.getParameter("productId2");
		Products product2 = new Products(productIdDelete);
		productRepository.delete(product2);
		PrintWriter out = response.getWriter();
		out.println("<head><script> alert('Product Deleted'); </script>");
		out.println("<body><h1>Product Deleted</h1>");
		
		
	}
	


}
}
	
	

