package com.fmcgglobal.web;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.fmcgglobal.model.Products;
import com.fmcgglobal.repository.ProductRepository;

public class DeleteServlet extends HttpServlet{
	ProductRepository productRepository = new ProductRepository();
	
	@Override
public void init() throws ServletException {
		productRepository = new ProductRepository();
		
	}

	
	@Override
	protected void doPost(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {
		
		
		String productIdDelete = request.getParameter("productId");
		Products product2 = new Products(productIdDelete);
		productRepository.delete(product2);
		PrintWriter out = response.getWriter();
		out.println("<head><script> alert('Product Deleted'); </script>");
		out.println("<body><h1>Product Deleted</h1>");
		
		
		
	}
}
