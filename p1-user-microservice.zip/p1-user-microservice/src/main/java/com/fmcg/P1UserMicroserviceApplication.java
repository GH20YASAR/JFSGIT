package com.fmcg;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class P1UserMicroserviceApplication {

	public static void main(String[] args) {
		SpringApplication.run(P1UserMicroserviceApplication.class, args);
	}

}
