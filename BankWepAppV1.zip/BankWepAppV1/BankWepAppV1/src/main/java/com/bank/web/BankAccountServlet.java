package com.bank.web;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.bank.model.Accounts;
import com.bank.repository.AccountRepository;

public class BankAccountServlet extends HttpServlet {
	AccountRepository accountRepository = null;

	@Override
	public void init() throws ServletException {
		accountRepository = new AccountRepository();
	}

	@Override
	protected void service(HttpServletRequest request, HttpServletResponse response)
			throws ServletException, IOException {

//		List<Product> productsList = productRepository.findAll();
//		if (productsList.size() > 0) {
//			productsList.forEach(System.out::println);
//		} else {
//			System.out.println("NO PRODUCTS");
//		}
		PrintWriter printWriter = response.getWriter();
		printWriter.println("<html>");
		printWriter.println("<body style= 'background-color: blueviolet'><style>table, th, td {border: 1px solid black;background-color: white;padding: 1mm;width:30cm;}</style><h1>Servlets</h1>");
		printWriter.println("<h4 style='color:green'><table><tr><th>Account_Number</th><th>UserName</th><th>Account_Balance</th></tr>");
		List<Accounts> accountsList = accountRepository.findAll();
		if (accountsList.size() > 0) {
			accountsList.forEach(accounts -> printWriter.println("<tr><td>"+accounts.getAccountNo() +"</td><td>"+ accounts.getUserName()+"</td><td>"+ accounts.getAccountBalance()+ "</td></tr> </h4>"));
		}
		

		
 
	 
 }
}








