package com.bank.repository;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

public class MySQLDBConnection {
	public static Connection getConnection() {
		Connection connection = null;
		
		try {

			Class.forName("com.mysql.cj.jdbc.Driver");

			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/BANKACCOUNT", "root", "mysql");
//System.out.println("Connection established");
			return connection;
		} catch (ClassNotFoundException classNotFoundException) {
			System.out.println("Driver could not be loaded " + classNotFoundException);
		} catch (SQLException sqlException) {
			System.out.println("Database Connection Problems " + sqlException);
		}
		return null;
	}

public static ResultSet getResultSet(String selectQuery) {
	try {
	
		Connection connection = getConnection();
	
		Statement statement = connection.createStatement();
		
		ResultSet resultSet = statement.executeQuery(selectQuery);
		return resultSet;
	} catch (SQLException sqlException) {
		System.out.println("Cannot execute query : " + sqlException);
	}
	return null;
}
public static int updateRecord(String updateQuery) {
	int rowsUpdated = 0;
	try {
		
		Statement statement = getConnection().createStatement();
		
		rowsUpdated = statement.executeUpdate(updateQuery);
		
		
		if(rowsUpdated > 0 ) {
			//System.out.println("Updated Record successfully!");
		}
		else
		{
			System.out.println("The record could not be updated....");
		}
	} catch (SQLException sqlException) {
		System.out.println("Cannot execute query : " + sqlException);
	}
	return rowsUpdated;
	
}
}