package com.bank.model;

public class Users {
	
	private String userName;
	private String password;
	private String creationDate;
	private int noOfAccounts;
	private long listOFAccountNumbers;
	private float totalBalance;
	private long contactNumber;
	
	
	


public Users(String userName,String password ,String  creationDate, int noOfAccounts,long listOfAccountNumbers,float totalBalance,long contactNumber)
{
	this.userName = userName;
	this.password = password;
	this.creationDate = creationDate;
	this.noOfAccounts = noOfAccounts;
	this.listOFAccountNumbers = listOfAccountNumbers;
	this.totalBalance = totalBalance;
	this.contactNumber= contactNumber;
}





public String getUserName() {
	return userName;
}





public String getPassword() {
	return password;
}





public String getCreationDate() {
	return creationDate;
}





public int getNoOfAccounts() {
	return noOfAccounts;
}





public long getListOFAccountNumbers() {
	return listOFAccountNumbers;
}





public float getTotalBalance() {
	return totalBalance;
}





public long getContactNumber() {
	return contactNumber;
}





@Override
public String toString() {
	return "userName=  " + userName + " password=  " + password + " creationDate=  " + creationDate
			+ " noOfAccounts=  " + noOfAccounts + " listOFAccountNumbers=   " + listOFAccountNumbers + " totalBalance=   "
			+ totalBalance + " contactNumber=  " + contactNumber ;
}
}

