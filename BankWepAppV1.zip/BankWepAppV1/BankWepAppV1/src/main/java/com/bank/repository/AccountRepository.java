package com.bank.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bank.model.Accounts;



public class AccountRepository {
	public List<Accounts> findAll() {
		
		List<Accounts> accountsList = new ArrayList<Accounts>();
		ResultSet resultSet = MySQLDBConnection.getResultSet("SELECT * FROM ACCOUNTS"); 
		
		try {
			while(resultSet.next()) {

				long accountNumber = resultSet.getLong("ACCOUNT_NUMBER");
				String userName = resultSet.getString("USERNAME");
				float accountBalance= resultSet.getFloat("ACCOUNT_BALANCE");
				
				 
				
				Accounts account = new Accounts(accountNumber,userName,accountBalance);
				accountsList.add(account);
			}
			return accountsList;
		} catch (SQLException sqlException) {
			System.out.println("Problem in Result Set " + sqlException);
		}
		return null;
	}
	
}
	
//	public void update(){
//		String updateQuery = "UPDATE PRODUCTS SET PRODUCT_NAME = '"+.getProductName()+"' WHERE PRODUCT_ID = '"+product.getProductId()+"';";
//		MySQLDBConnection.updateRecord(updateQuery);
//}
