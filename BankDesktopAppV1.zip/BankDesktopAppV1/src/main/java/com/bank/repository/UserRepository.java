package com.bank.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bank.model.Users;

public class UserRepository {
public List<Users> findAll() {
		
		List<Users> userList = new ArrayList<Users>();
		ResultSet resultSet = MySQLDBConnection.getResultSet("SELECT * FROM USERS"); 
		
		try {
			while(resultSet.next()) {

				
				String userName = resultSet.getString("USERNAME");
				String password= resultSet.getString("PASSWORD");
				String creationDate = resultSet.getString("CREATION_DATE");
				int noOfAccounts =resultSet.getInt("NO_OF_ACCOUNTS");
				long listOfAccountNumbers =resultSet.getLong("LIST_OF_ACCOUNT_NUMBERS");
				float totalBalance =resultSet.getFloat("TOTAL_BALANCE");
				long contactNO =resultSet.getLong("CONTACT_NO");
				
				Users users = new Users(userName,password,creationDate,noOfAccounts,listOfAccountNumbers,totalBalance,contactNO);
				userList.add(users);
			}
			return userList;
		} catch (SQLException sqlException) {
			System.out.println("Problem in Result Set " + sqlException);
		}
		return null;
	}
}

