package com.bank.repository;

import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.bank.model.Transactions;

public class TransactionRepository{
public List<Transactions> findAll() {
		
		List<Transactions> transList = new ArrayList<Transactions>();
		ResultSet resultSet = MySQLDBConnection.getResultSet("SELECT * FROM TRANSACTIONS"); 
		
		try {
			while(resultSet.next()) {

				
				String transactionId = resultSet.getString("TRANSACTION_ID");
				long fromAccount= resultSet.getLong("FROM_ACCOUNT");
				long toAccount = resultSet.getLong("TO_ACCOUNT");
				float Amount =resultSet.getFloat("AMOUNT");
		
				
				Transactions transactions= new Transactions(transactionId,fromAccount,toAccount,Amount);
				transList.add(transactions);
			}
			return transList;
		} catch (SQLException sqlException) {
			System.out.println("Problem in Result Set " + sqlException);
		}
		return null;
	}


public boolean validateBalance (long accountNumber,float amount)  {
	
	 boolean isValid= false;
	 
	
	 
	 String query = "select * from accounts where ACCOUNT_BALANCE>="+amount+ "and ACCOUNT_NUMBER ="+accountNumber;
	 
	 ResultSet resultSet = MySQLDBConnection.getResultSet(query); 
	 	try {
			while(resultSet.next()) {
				isValid = true;
			}
		} catch (SQLException sqlException) {
			
			System.out.println("Problem in Result Set " + sqlException);
		}
 	
	return isValid;
	  }


public void update(Transactions transactions){
	
	String updateQuery = "update  accounts set account_balance = (account_balance -"+ transactions.getAmount()+") where account_number = '"+transactions.getFromAccount()+"'";
	
	MySQLDBConnection.updateRecord(updateQuery);
	
	String updateQuery2 = "update  accounts set account_balance = (account_balance +"+ transactions.getAmount()+") where account_number = '"+transactions.getToAccount()+"'";
	
	MySQLDBConnection.updateRecord(updateQuery2);
	

}
	


}
