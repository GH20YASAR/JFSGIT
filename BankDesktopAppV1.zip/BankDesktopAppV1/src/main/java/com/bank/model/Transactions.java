package com.bank.model;

public class Transactions {
	
		
		private String transactionId;
		private long fromAccount ;
		private long toAccount;
		private float amount;
	
		
		public Transactions(String transactionId,long  fromAccount ,long toAccount , float amount)
		{
			this.transactionId = transactionId;
			this.fromAccount = fromAccount;
			this.toAccount = toAccount ;
			this.amount = amount;
		}
		public Transactions(long fromAccount , long toAccount , float amount)
		{
			this.fromAccount = fromAccount;
			this.toAccount = toAccount ;
			this.amount = amount;
			
		}


		public String getTransactionId() {
			return transactionId;
		}


		public long getFromAccount() {
			return fromAccount;
		}


		public long getToAccount() {
			return toAccount;
		}


		public float getAmount() {
			return amount;
		}


		@Override
		public String toString() {
			return "\n\ntransactionId=" + transactionId + " \nfromAccount=" + fromAccount + "\ntoAccount="
					+ toAccount + " \namount=" + amount ;
		}
}
		
		
		
