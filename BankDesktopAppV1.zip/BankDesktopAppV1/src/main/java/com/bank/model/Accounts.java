package com.bank.model;

public class Accounts {
	private long accountNo;
	private String userName;
	private float accountBalance;
	


public Accounts(long accountNo,String userName ,float accountBalance)
{
	this.accountNo = accountNo;
	this.userName = userName;
	this.accountBalance = accountBalance;
}



public Accounts() {
	// TODO Auto-generated constructor stub
}
public Accounts(long accountNo,float accountBalance)
{
	this.accountNo = accountNo ;
	this.accountBalance = accountBalance;
}

public long getAccountNo() {
	return accountNo;
}



public String getUserName() {
	return userName;
}



public float getAccountBalance() {
	return accountBalance;
}



@Override
public String toString() {
	return "\n\naccountNo =  " + accountNo + "\nuserName =  " + userName + " \naccountBalance =" + accountBalance ;
}
}
