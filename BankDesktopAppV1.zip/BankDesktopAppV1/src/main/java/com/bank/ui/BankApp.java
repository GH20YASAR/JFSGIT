package com.bank.ui;

import java.util.List;
import java.util.Scanner;

import com.bank.model.Accounts;
import com.bank.model.Transactions;
import com.bank.model.Users;
import com.bank.repository.AccountRepository;
import com.bank.repository.TransactionRepository;
import com.bank.repository.UserRepository;



public class BankApp {
	Scanner scanner = null;

  AccountRepository accountRepository= null;
  UserRepository userRepository = null;
  TransactionRepository transrepository = null;


public static void main(String[] args)  {
BankApp bankApp = new BankApp();
bankApp.displayMenu();
}

public BankApp() {
	scanner = new Scanner(System.in);
	accountRepository = new AccountRepository();
	userRepository = new UserRepository();
	transrepository = new TransactionRepository();
}


private void displayMenu(){
	System.out.println("WELCOME TO ICICIC BANK");
	System.out.println("===================");
	while_label: while (true) {
		System.out.println("\n1. DISPLAY ACCOUNT DETAILS");
		System.out.println("\n2 .DISPLAY USER DETAILS");
		System.out.println("\n3.DISPLAY TRANSCATION DETAILS");
		System.out.println("\n4.TRANSFER AMOUNT");
		System.out.print("\n\nENTER CHOICE : ");
		int choice = Integer.parseInt(scanner.nextLine());
	System.out.println();

		switch (choice) {
		case 1: {
		findAllAccounts();
			break;
		}
		case 2:{
			findAllUsers();
			break;
		}
		case 3 : {
			findAllTransactions();
			break;
		}
		case 4 : {
			transferMoney();
			findAllAccounts();
			break;
		}
		case 0: {
			break while_label;
		}

		default: {
			System.out.println("Enter a valid option");
		}
		}
	}
	System.out.println("THANK YOU !!!");
	System.out.println("COME AGAIN");
}



private void findAllAccounts() {
	List<Accounts> accountsList = accountRepository.findAll();
	if (accountsList.size() > 0) {
		accountsList.forEach(System.out::println);
	} else {
		System.out.println("NO PRODUCTS");
	}
}
private void findAllUsers() {
	List<Users> userList = userRepository.findAll();
	if (userList.size() > 0) {
		userList.forEach(System.out::println);
	} else {
		System.out.println("NO PRODUCTS");
	}
}

	private void findAllTransactions() {
		List<Transactions> transList = transrepository.findAll();
		if (transList.size() > 0) {
			transList.forEach(System.out::println);
		} else {
			System.out.println("NO PRODUCTS");
		}
	}
	

 private void transferMoney () {
	 System.out.println("ENTER FROM ACCOUNT NO ");
 
	long accountNo1 = Long.parseLong(scanner.nextLine());
	System.out.println("ENTER TO ACCOUNT NO");
	long accountNo2  = Long.parseLong(scanner.nextLine());
	System.out.println("ENTER AMOUNT TO TRANSFER");
	float amount = Float.parseFloat(scanner.nextLine());
	
	Transactions transactions = new Transactions(accountNo1, accountNo2,amount);
	
	boolean validBalance = transrepository.validateBalance(accountNo1,amount);
	
	if(validBalance) {
		
		
		transrepository.update(transactions);
		System.out.println("Amount Transfered Successfully");
		
	}else {
		
		System.out.println(accountNo1 +"account1 dont habve sufficitent balance to transfer" );
	}


	
 }
 
 
 
 

		
		
		
 
	 
 }








