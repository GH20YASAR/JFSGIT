package collections;

import java.util.ArrayList;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class GetElementsHashSet {
	public static void main(String[] args) {
	//usingArray();
	useForEach();
	//	useArrayList();
	}

	private static void usingArray() {
		Set<String> hashSet1 = new HashSet<String>();
		hashSet1.add("mango");
		hashSet1.add("apple");
		hashSet1.add("orange");
		hashSet1.add("pinapple");
//		int size = hashSet1.size();
//		String stringArrayForCopyingElements[] = new String[size];
//		String[] hashSetArray = hashSet1.toArray(stringArrayForCopyingElements);
		String[] hashSetArray = hashSet1.toArray(new String[hashSet1.size()]);
		for (String fruit : hashSetArray) {
			System.out.println(fruit);
		}
		System.out.println(hashSetArray[3]);
	}

	private static void useForEach() {
		Set<String> hashSet1 = new HashSet<String>();
		hashSet1.add("mango");
		hashSet1.add("apple");
		hashSet1.add("orange");
		hashSet1.add("pinapple");
		System.out.println(hashSet1);
		int index = 0, searchIndex = 3;
		for (String fruit : hashSet1) {
			if (index == searchIndex) {
				System.out.println(fruit);
				break;
			}
			index++;
		}
		hashSet1.forEach(System.out::print);
	}
	private static void useArrayList() {
		Set<String> hashSet1 = new HashSet<String>();
		hashSet1.add("mango");
		hashSet1.add("apple");
		hashSet1.add("orange");
		hashSet1.add("pinapple");
		System.out.println(hashSet1);
		List<String> fruitsList = new ArrayList<String>(hashSet1);
		System.out.println(fruitsList.get(3));
		
	}
}