package collections;

import java.util.LinkedHashSet;
import java.util.List;
import java.util.Set;

public class RemoveDuplicatesWithInsertionOrder {
	public static void main(String[] args) {
		List list = CollectionRepo.getArrayList();
		System.out.println(list);
		Set set =  new LinkedHashSet(list);
	System.out.println(set);
	}
}