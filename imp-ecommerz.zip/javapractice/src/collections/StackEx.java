package collections;

import java.util.Stack;

public class StackEx {
	
	public static void main(String[] args) {
		Stack<String> methodCallStack = new Stack<>();
		methodCallStack.push("main");
		methodCallStack.add("controller");
		methodCallStack.add("service");
		methodCallStack.add("rep");
		System.out.println(methodCallStack);
	System.out.println(methodCallStack.search("rep"));
		System.out.println(methodCallStack.search("controller"));
		System.out.println(methodCallStack.search("ask"));
		System.out.println(methodCallStack.pop());
	System.out.println(methodCallStack);
		

System.out.println(methodCallStack.peek());	
//		System.out.println(methodCallStack.peek());	
//		System.out.println(methodCallStack);
		while(!methodCallStack.empty()) {
			String methodString = methodCallStack.pop();
			System.out.println(methodString);
		}
		
		System.out.println(methodCallStack);
		
		methodCallStack.add("main");
		methodCallStack.add("controller");
		methodCallStack.add("service");
		methodCallStack.add("rep");
		

	}
	
	
}
