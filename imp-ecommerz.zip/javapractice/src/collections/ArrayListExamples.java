package collections;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

public class ArrayListExamples {
	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(1);
		list.add(3);
		list.add(8);
		list.add(4);
		System.out.println(list);
		int size = list.size();
		System.out.println(size);
		int get = list.get(1);
		System.out.println(get);
		boolean isEmpty = list.isEmpty();
		System.out.println(isEmpty);
		list.add(2,5);
		System.out.println(list);
		boolean contains = list.contains(7);
		System.out.println(contains);
//		ArrayList list2 =   (ArrayList) list.clone();
//		System.out.println(list2);
//		ArrayList myList = new ArrayList();
//		Object object = new Integer(10);
		Collections.sort(list);
		System.out.println(list);
		Collections.reverse(list);
		System.out.println(list);
		List <Integer> mylist = list.subList(1, 3);
		System.out.println(mylist);
		list.removeIf(n -> (n % 2 == 0));
		System.out.println(list);
		list..


	
		
	}
}
