package collections;


import java.util.Arrays;
import java.util.Collection;
import java.util.HashSet;
import java.util.List;
import java.util.Set;

public class SetEx {
	public static void main(String[] args) {
		Double[] doubleArray = new Double[] { 1d, 3d, 7d, 5d, 4d, 0d, 7d };
//		Integer[] integerArray = new Integer[] { 1, 3, 7, 5, 4, 0, 7, 5,100,200,700,300 };
		System.out.println(doubleArray);
		for (Double integer : doubleArray) {
			System.out.println(integer);
		}

		List<Double> list = Arrays.asList(doubleArray);
		System.out.println(list);


		Collection<Double> hashSet = new HashSet<Double>();
		if(hashSet.isEmpty()) {
			System.out.println("Collection is empty!");
		}
//		System.out.println(hashSet);
		hashSet.addAll(list);
		hashSet.add(2d);
		hashSet.add(1d);
//		hashSet.add(100);
//		hashSet.add(4000);
		System.out.println(hashSet);
		hashSet.remove(2d);
		System.out.println(hashSet);
		if(hashSet.isEmpty()) {
			System.out.println("Collection is empty!");
		}
		else {
			System.out.println("Collection is not empty!");
		}
		Set<String> hashSet1 = new HashSet<String>();
		hashSet1.add("mango");
		hashSet1.add("apple");	
		hashSet1.add("orange");	
		hashSet1.add("pinapple");	
		System.out.println(hashSet1);
	}
}