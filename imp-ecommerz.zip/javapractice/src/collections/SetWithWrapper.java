package collections;

import java.util.HashSet;

public class SetWithWrapper {
	public static void main(String[] args) {
		wrapperSet();
//		objectSet();
	}

	private static void wrapperSet() {
		HashSet<Number> wrapperSet = new HashSet<Number>();
		Integer integer = 100;
//Integer integer2 = new Integer(100);
//Integer integer3 = Integer.valueOf(100);
		Float float1 = 50.5f;
		Number number = integer;
		wrapperSet.add(number);
		wrapperSet.add((Number) integer);
		wrapperSet.add(integer);
//		wrapperSet.add((Number) float1);
		wrapperSet.add(float1);
//		System.out.println(wrapperSet);

//		HashSet wrapperHashSet = (HashSet)wrapperSet;
//		Set<Number> wrapperSetClone = (Set<Number>)wrapperHashSet.clone();
//		wrapperSetClone.add(55.5);
		
		HashSet<Number>wrapperSetClone1 =(HashSet<Number>) wrapperSet.clone();
		HashSet<Number> wrapperSetClone = wrapperSet;
		wrapperSetClone.add(55.5);
		System.out.println(wrapperSet);
		System.out.println(wrapperSetClone);
		System.out.println(wrapperSetClone1);
	}
}

//	private static void objectSet() {
//		Set wrapperSet = new HashSet();
////		Set<Object> wrapperSet = new HashSet<Object>();
//		Integer integer = 100;
////Integer integer2 = new Integer(100);
////Integer integer3 = Integer.valueOf(100);
//		Float float1 = 50.5f;
//		Number number = integer;
//		wrapperSet.add(number);
//		wrapperSet.add((Number) integer);
//		wrapperSet.add(integer);
////		wrapperSet.add((Number) float1);
//		wrapperSet.add(float1);
//		Test test = new Test();
//		wrapperSet.add(test);
//		System.out.println(wrapperSet);
//	}
//}

//class Test {
//
//	@Override
//	public String toString() {
//		return "Test";
//	}
//
//}