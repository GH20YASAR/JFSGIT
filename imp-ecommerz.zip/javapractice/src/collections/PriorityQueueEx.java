package collections;

import java.util.Iterator;
import java.util.PriorityQueue;
import java.util.Queue;

public class PriorityQueueEx {
	public static void main(String[] args) {
		Queue<Integer> queue = new PriorityQueue<>();
		queue.add(100);
		queue.add(200);
		queue.add(100);
		queue.add(200);
		queue.add(100);
		queue.add(1);
		queue.add(10);
		System.out.println(queue);
		Iterator iterator = queue.iterator();
		while(iterator.hasNext()) {
			System.out.println(iterator.next());
		}
	}
}