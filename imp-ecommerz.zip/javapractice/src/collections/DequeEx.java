package collections;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Deque;

public class DequeEx {
	public static void main(String[] args) {
		Deque<Integer> deque = new ArrayDeque<Integer>(10);
		deque.add(300);
		deque.add(100);
		deque.add(200);
		deque.add(300);
		for (Integer element : deque) {
			System.out.println("Element : " + element);
		}
		System.out.println(deque);
//		deque.clear();

		deque.addFirst(-1);
		deque.addFirst(-2);
		deque.addLast(1);
		deque.addLast(2);
		System.out.println(deque);

		System.out.println(deque.getFirst());
		System.out.println(deque.getLast());
		System.out.println(deque);

		deque.remove();
		System.out.println(deque);
		System.out.println(deque.removeFirstOccurrence(300));
//		System.out.println(deque.removeFirstOccurrence(new Exception()));
		System.out.println(deque);
		
		System.out.println("ARRAY LIST ****");
		ArrayList arrayList1 = new ArrayList();
		//arrayList1.add(null);
		arrayList1.add("test");
	//arrayList1.add(null);
	//arrayList1.add(new Number(100));
		//arrayList1.add(new Integer(100));
	//arrayList1.add(Integer.valueOf(100));
		arrayList1.add("rest");
		arrayList1.add("best");
		System.out.println(arrayList1);
	Collections.sort(arrayList1, Collections.reverseOrder());
		//Collections.sort(arrayList1);
		//Collections.reverse(arrayList1);
		System.out.println(arrayList1);
		
//		Set set = new HashSet();
//		set.add(null);
//		set.add("test");
//		set.add(null);
////		set.add(new Number(100));
//		set.add(new Integer(100));
//		set.add(Integer.valueOf(100));
//		System.out.println(set);
//		
//		Map<Integer,String> map = new HashMap<Integer, String>();
//		map.put(2, "cherry");
//		map.put(null, "apple");
//		map.put(null, "orange");
//		map.put(1, "mango");
//		map.put(200, "mango");
//		map.put(20, "cherry");
//		System.out.println(map);
	}
}