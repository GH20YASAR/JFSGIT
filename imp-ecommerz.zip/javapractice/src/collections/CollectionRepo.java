package collections;

import java.util.ArrayList;
import java.util.List;

public class CollectionRepo {
	public static List getArrayList() {
		List<String> colorsList = new ArrayList<String>();
		colorsList.add("Green");
		colorsList.add("Red");
		colorsList.add("Yellow");
		colorsList.add("Green");
		colorsList.add("Blue");
		colorsList.add("Red");
		return colorsList;
	}
}

