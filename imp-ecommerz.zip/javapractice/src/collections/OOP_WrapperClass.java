package collections;

public class OOP_WrapperClass {

}
