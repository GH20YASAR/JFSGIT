package java8;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;
import java.util.stream.Stream;

public class MapFilterReduce {
	public static void main(String[] args) {
		//oldStyleIteration();
		mappingOperation();
		filter_operation();
		reduction_operation();
		
	}
	
	private static void oldStyleIteration() {
		ArrayList<Integer> integerlist = new ArrayList<Integer>();
		integerlist.add(1);
		integerlist.add(2);
		integerlist.add(3);
		integerlist.add(4);
		
		//oldest form of iteration
		for(int i =0; i<integerlist.size();i++) {
			Integer number = integerlist.get(i);
			System.out.println(number);
			
		}
		//Enhanced for loop
		System.out.println("using enhanced for loop");
		for(Integer number1 : integerlist)
		{
			System.out.println(number1);
		}
		
		//using Iterator
		System.out.println("using iterator");
		Iterator<Integer> iterator = integerlist.iterator();
		while(iterator.hasNext())
		{
			Integer number3 = iterator.next();
			System.out.println(number3);
		}
		

	}


private static void mappingOperation()
{
	 
        // A simple array
        String[] players = new String[] { "sam", "peter", "billy", "lilly" };
//        Integer[] playerAge = new Integer[] { 1,2,3,4,5 };
        Stream<String> playerStream = Arrays.stream(players);
//        Stream<Integer> playerAgeStream = Arrays.stream(playerAge);
        Stream<String> upperCaseStream = playerStream.map(change -> change.toUpperCase());
        //or
       // Stream<String> upperCaseStream = playerStream.map(player -> player.toUpperCase());
//        upperCaseStream.forEach(player -> System.out.println(player));
        upperCaseStream.forEach(System.out::println);        
        // Converting the stream back to an array
//        String[] newPlayer = upperCaseStream.toArray(String[] :: new);
//        for(String player :newPlayer) {
//            System.out.println(player);
//        }
//        for(String player :players) {
//            System.out.println(player);
//        }
        
//       Arrays.stream(players).map(player -> player.toUpperCase()).forEach(System.out::println);
    }

	private static void filter_operation() {
        // A simple array
        String[] players = new String[] { "sam", "peter", "billy", "lilly" };
//        Integer[] playerAge = new Integer[] { 1,2,3,4,5 };
        Stream<String> playerStream = Arrays.stream(players);
//        Stream<Integer> playerAgeStream = Arrays.stream(playerAge);
        Stream<String> filteredStream = playerStream.filter(player -> player.length() > 3);
//        upperCaseStream.forEach(player -> System.out.println(player));
        filteredStream.forEach(System.out::println);        
    }
private static void reduction_operation() {
    // A simple array
    int[] playerSalary = new int[] { 7000, 100, 200 };
    int sum = 0;
    for(int i = 0; i< playerSalary.length; i++) {
        sum = sum + playerSalary[i];
    }
    System.out.println(sum);    
    System.out.println(Arrays.stream(playerSalary).sum());
}
}
