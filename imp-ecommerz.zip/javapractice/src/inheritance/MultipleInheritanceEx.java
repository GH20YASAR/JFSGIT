//package inheritance;
//
//public class MultipleInheritanceEx {
//
//}
//class Watch{
//	
//}
//class Clock{
//	
//}
//class Time extends Watch,Clock{
//	
//}
