package inheritance;

public class HierarchialInheritanceEx {

}
class Watch2{
	
}
class SmartWatch2 extends Watch2{
	
}
class AnalogWatch extends Watch2{
	
}
