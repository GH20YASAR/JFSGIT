//package inheritance;
//
//public class SingleInheritanceEx {
//
//}
// class Watch{
//	
//}
//class Smartwatch extends Watch {
//	
//}