package overloading;

import java.util.Scanner;

public class BooleanEx {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the first value");
		boolean input1 = sc.nextBoolean();
		System.out.println("Enter the second value");
		boolean input2 = sc.nextBoolean();
		BooleanEx input = new BooleanEx();
		input.checkBoolean(input1,input2);
		
	}
	
	public void checkBoolean(boolean b1,boolean b2)
	{
		if(b1 == true || b2 == true)
		{
			System.out.println("true");
		}
		else if(b1 == true || b2 == false)
		{
			
		}
	}

}
