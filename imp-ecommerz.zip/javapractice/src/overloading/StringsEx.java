package overloading;

import java.util.Scanner;

public class StringsEx {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter your first name");
		String input1 = sc.nextLine();
		System.out.println("Enter your last name");
		String input2 = sc.nextLine();
		StringsEx input = new StringsEx();
				input.addStrings(input1, input2);
		
		
		
	}
	public void addStrings(String str1,String str2)
	{
		String result = str1 + str2;
		System.out.println("full name :"+ result);
		
	}

}
