package basic;

public class WrapperEx {
	public static void main(String[] args) {
		String idString = "12";
		int idInt = Integer.parseInt(idString);
		int result = idInt +idInt;
		System.out.println(result);
		
		int i=100;
//		ArrayList<Integer>numberList = new ArrayList<Integer>();
//		numberList.add(i);
//		primitive to wrapper (boxing)
//		Integer integerVal= i;
//		numberList.add(integerVal);
		Integer integerVal1 = Integer.valueOf(i);
		System.out.println(integerVal1);
		
	
		//wrapper to primitive(unboxing)
		int intValue = integerVal1;
		System.out.println(intValue);
		
		
	}

}
