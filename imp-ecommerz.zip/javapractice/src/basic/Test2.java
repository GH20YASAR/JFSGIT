package basic;



import java.util.ArrayList;

public class Test2 {
	public static void main(String[] args) {
		ArrayList<Integer> list = new ArrayList<Integer>();
		list.add(1);
		list.add(3);
		list.add(8);
		list.add(4);
		System.out.println(list);
		int size = list.size();
		System.out.println(size);
		int get = list.get(1);
		System.out.println(get);
		boolean isEmpty = list.isEmpty();
		System.out.println(isEmpty);
		list.add(2,5);
		System.out.println(list);
		boolean contains = list.contains(7);
		System.out.println(contains);
		list.set(1, 4);
		System.out.println(list);
		
		//interchanging element by one position in arraylist
		for(int i= 0 ; i < list.size()-1;i++)
		{
			
int temp = list.get(i+1);
list.set(i,temp );
		}
		
		list.set((list.size()-1), 1);
		System.out.println(list);


	
	//searching element in arraylist
		int position = list.indexOf(8);
		System.out.println(position);
	//searching particular index position element
	for(int i= 0 ; i < list.size();i++)
	{
		
		if(i == 3) {
		
		int temp1 = list.get(i);
		System.out.println(temp1);
		}
	
	}
	int sum = 0;
	//Adding element in the list
	for(int i= 0 ; i < list.size();i++)
	{
		
		sum = sum + list.get(i);
	
}
	System.out.println(sum);
	
	//fibonocci series in the list
	
	
	for(int i= 0 ; i < list.size();i++)
	{
		
	}
	
	
	
	
	
	
	
	
	
	}
}
