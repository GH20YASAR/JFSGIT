package basic;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.TreeMap;


 public class Test1
{
	public static void main (String[] args) 
	{
List<Employee> list = new ArrayList <Employee>();
Employee employee1 = new Employee("yasar", "petroleum",25, 50000);
list.add(employee1);
list.add(new Employee("santosh", "IT", 26,70000));
list.add(new Employee("nishanth", "IT", 27,60000));
list.add(new Employee("ASHWATH", "Chemical", 24,40000));
groupEmployees(list);

}

public static void groupEmployees(List<Employee>list) {
	
	Map <String,List<Employee>> map = new TreeMap <>();
	for(Employee yasar : list)
	{
		if(map.get(yasar.departmentString)== null)
		{
			List<Employee> list1 = new ArrayList <Employee>();
			list1.add(yasar);
			map.put(yasar.departmentString,list1);
		}
		else {
			List<Employee> list1 = map.get(yasar.departmentString);
			list1.add(yasar);
			
		}
	
}
//	System.out.println(map);
	map.forEach((Key,value) -> System.out.println("key : "+ Key+" value : "+value));
}

		

	
}

 
 
 
 
 
 
 
 
 class Employee
 {
	 String employeeString;
	 String departmentString;
	 int age;
	 int salary;
	 
	 
public Employee(String employeeString , String deparmenString ,int age , int salary) {
	
	this.employeeString = employeeString;
	this.departmentString = deparmenString;
	this.age = age;
	this.salary = salary;
}


@Override
public String toString() {
	return " employeeString=" + employeeString + ", departmentString=" + departmentString + ", age=" + age
			+ ", salary=" + salary +"\n";
}

	
}
 