package calculator;

import java.util.Scanner;

public class CalculatorOverloading {
public static void main(String[] args) {
	CalculatorOverloading operation = new CalculatorOverloading();
	
	Scanner Scannerobject = new Scanner(System.in);
	System.out.println("Enter Number 1");
	String no1 = Scannerobject.nextLine();
	System.out.println("Enter Number 2");
	String no2 = Scannerobject.nextLine();
	double n1 = Double.parseDouble(no1);
	double n2 = Double.parseDouble(no2);	
	int n3 = Integer.parseInt(no1);
	int n4 = Integer.parseInt(no2);	
	operation.add(n1,n2);
	operation.add(n3,n4);
	operation.add(no1,no2);
	
	
}

public void add(int n1, int n2)
{
	int result = n1 + n2;
	System.out.println("result :" + result);
}
public void add(double n1, double n2)
{
	double result = n1 + n2;
	System.out.println("result :" + result);
}
public void add (String s1 , String s2){
	
		String result = s1 + s2;
		System.out.println("result :" + result);
}

}
	






