package calculator;

import java.util.Scanner;

public class Calculator2 {
	public static void main(String[] args)
		{
		Calculator2 operation = new Calculator2();
		
			Scanner Scannerobject = new Scanner(System.in);
			System.out.println("Enter Number 1");
			String no1 = Scannerobject.nextLine();
			System.out.println("Enter Number 2");
			String no2 = Scannerobject.nextLine();
			double n1 = Double.parseDouble(no1);
			double n2 = Double.parseDouble(no2);	
			operation.addDouble(n1,n2);
			
		}
		
		public void addDouble(double n1, double n2)
		{
			double result = n1 + n2;
			System.out.println("result :" + result);
		}
}


