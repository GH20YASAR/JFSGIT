package exception;

import java.util.Scanner;

public class HandledException {

	public static void main(String args[]) {
		HandledException operation = new HandledException();
		System.out.println("Addition");
		operation.add();
	/*	System.out.println("Subtraction");
		operation.subtract();
		System.out.println("Multiplication");
		operation.multiply();
		System.out.println("Diviison");
		operation.divide();
		System.out.println("Modulus");
		operation.modulus();*/

	}
 void add() {
		Scanner Scannerobject = new Scanner(System.in);
		System.out.println("Enter Number 1");
		String no1 = Scannerobject.nextLine();
		int n1 = 0;
		try {
			n1 = Integer.parseInt(no1);

		} catch (NumberFormatException numberFormatExceptionObject) {
			System.out.println("Enter valid number1");
		}
	int n2 = 0;
		try {
			System.out.println("Enter Number 2");
			String no2 = Scannerobject.nextLine();
			n2 = Integer.parseInt(no2);
			int result = n1 + n2;
			System.out.println("Result is : " + result);
		} catch (NumberFormatException numberFormatExceptionObject) {
			System.out.println("Enter valid number2");
		}
	}

	public void subtract() {
		Scanner Scannerobject = new Scanner(System.in);
		System.out.println("Enter Number 1");
		String no1 = Scannerobject.nextLine();
		System.out.println("Enter Number 2");
		String no2 = Scannerobject.nextLine();
		int n1 = Integer.parseInt(no1);
		int n2 = Integer.parseInt(no2);
		int result = n1 - n2;
		System.out.println("Result is : " + result);
	}

	public void multiply() {
		Scanner Scannerobject = new Scanner(System.in);
		System.out.println("Enter Number 1");
		String no1 = Scannerobject.nextLine();
		System.out.println("Enter Number 2");
		String no2 = Scannerobject.nextLine();
		int n1 = Integer.parseInt(no1);
		int n2 = Integer.parseInt(no2);
		int result = n1 * n2;
		System.out.println("Result is : " + result);
	}

	public void divide() {
		Scanner Scannerobject = new Scanner(System.in);
		System.out.println("Enter Number 1");
		String no1 = Scannerobject.nextLine();
		System.out.println("Enter Number 2");
		String no2 = Scannerobject.nextLine();
		int n1 = Integer.parseInt(no1);
		int n2 = Integer.parseInt(no2);
		int result = n1 / n2;
		System.out.println("Result is : " + result);
	}

	public void modulus() {
		Scanner Scannerobject = new Scanner(System.in);
		System.out.println("Enter Number 1");
		String no1 = Scannerobject.nextLine();
		System.out.println("Enter Number 2");
		String no2 = Scannerobject.nextLine();
		int n1 = Integer.parseInt(no1);
		int n2 = Integer.parseInt(no2);
		int result = n1 % n2;
		System.out.println("Result is : " + result);
	}

}
