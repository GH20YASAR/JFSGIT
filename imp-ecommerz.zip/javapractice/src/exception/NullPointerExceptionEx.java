package exception;

import java.util.Scanner;

public class NullPointerExceptionEx {
	public static void main(String[] args) {
		Calculator operation = null;
		//Calculator operation = new Calculator();
		//operation = new Calculator();
		System.out.println("Addition");
		try {
			operation.add();
		} catch (Exception e) {

			System.out.println(e);
		}

		System.out.println("Subtraction");
		operation.subtract();
		System.out.println("Multiplication");
		operation.multiply();
		System.out.println("Diviison");
		operation.divide();
		System.out.println("Modulus");
		operation.modulus();
	}

}

class Calculator {

	public void add() {
		Scanner Scannerobject = new Scanner(System.in);
		System.out.println("Enter Number 1");
		String no1 = Scannerobject.nextLine();
		System.out.println("Enter Number 2");
		String no2 = Scannerobject.nextLine();
		int n1 = Integer.parseInt(no1);
		int n2 = Integer.parseInt(no2);
		int result = n1 + n2;
		System.out.println("Result is : " + result);
	}

	public void subtract() {
		Scanner Scannerobject = new Scanner(System.in);
		System.out.println("Enter Number 1");
		String no1 = Scannerobject.nextLine();
		System.out.println("Enter Number 2");
		String no2 = Scannerobject.nextLine();
		int n1 = Integer.parseInt(no1);
		int n2 = Integer.parseInt(no2);
		int result = n1 - n2;
		System.out.println("Result is : " + result);
	}

	public void multiply() {
		Scanner Scannerobject = new Scanner(System.in);
		System.out.println("Enter Number 1");
		String no1 = Scannerobject.nextLine();
		System.out.println("Enter Number 2");
		String no2 = Scannerobject.nextLine();
		int n1 = Integer.parseInt(no1);
		int n2 = Integer.parseInt(no2);
		int result = n1 * n2;
		System.out.println("Result is : " + result);
	}

	public void divide() {
		Scanner Scannerobject = new Scanner(System.in);
		System.out.println("Enter Number 1");
		String no1 = Scannerobject.nextLine();
		System.out.println("Enter Number 2");
		String no2 = Scannerobject.nextLine();
		int n1 = Integer.parseInt(no1);
		int n2 = Integer.parseInt(no2);
		int result = n1 / n2;
		System.out.println("Result is : " + result);
	}

	public void modulus() {
		Scanner Scannerobject = new Scanner(System.in);
		System.out.println("Enter Number 1");
		String no1 = Scannerobject.nextLine();
		System.out.println("Enter Number 2");
		String no2 = Scannerobject.nextLine();
		int n1 = Integer.parseInt(no1);
		int n2 = Integer.parseInt(no2);
		int result = n1 % n2;
		System.out.println("Result is : " + result);
	}

}
