package conditionalstatements;

import java.util.Scanner;

public class SwitchCaseEx {
	public static void main(String args[] ) {
		Scanner sc = new Scanner(System.in);
		System.out.println("Enter the colour :");
		String input = sc.nextLine();
		switch(input) {
		case "red" : System.out.println("The colour is red");
		break;
		case "blue" : System.out.println("The colour is blue");
		break;
		case "green" : System.out.println("The colour is green");
		break;
		case "orange" : System.out.println("The colour is orange");
		break;
		case "yellow" : System.out.println("The colour is yellow");
		break;
		case "rose" : System.out.println("The colour is rose");
		break;
		case "white" : System.out.println("The colour is white");
		break;
		case "black" : System.out.println("The colour is black");
		break;
		default : System.out.println("unavailable colour");
		break;
		}
	}

}
