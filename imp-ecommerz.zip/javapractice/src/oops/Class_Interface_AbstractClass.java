package oops;

public class Class_Interface_AbstractClass {

	public static void main(String[] args) {
	//	Account account ;
		// cannot instantiate the type account
		//account = new Account();
		System.out.println("Using Savings Account");
		Account account = new SavingAccount();
		account.displayAccountInfo();
		account.displayBankDetails();
		
		System.out.println("Using current Account");
		account = new CurrentAccount();
		account.displayAccountInfo(); 
		account.displayBankDetails();
		
		System.out.println("USING NET BANKING");
		NetBanking netBanking = null;
		netBanking = new SavingAccount();
		netBanking.transferAmount();
		
	
		
		System.out.println("USING debit cards");
		DebitCard debitCard = null;
		debitCard = new SavingAccount();
		debitCard.withdrawAmount();
		
		
		System.out.println("USING saving account");
		SavingAccount obj = new SavingAccount();
		obj.displayAccountInfo();
		obj.withdrawAmount();
		obj.transferAmount();
		obj.displayBankDetails();
		
		
//		System.out.println("USING NET BANKING");
//		NetBanking netBanking = null;
//		netBanking = obj.yasar();
//		
	}
}

interface NetBanking{
	public void transferAmount();
}

interface DebitCard{
	public  void withdrawAmount();
}



//abstract class cannot be instantiated
//inheritance is the purpose of abstract class
abstract class Account{
//abstract methods  do not specify a body
	//public abstract void displayAccountInfo(){
//
	//}
	
	public abstract void displayAccountInfo();
	public void displayBankDetails() {
		System.out.println("Citi Bank");
	}
}
// A class can extend from only one class but can implement multiple interfaces
class SavingAccount extends Account implements NetBanking ,DebitCard{
	//override the abstract method
	@Override
	public void displayAccountInfo()
	{
		System.out.println("Savings Account");
	}

	
	@Override
	public void withdrawAmount() {
		System.out.println("withdraw amount from savings bank account using debit card");
		
	}
	@Override
	public void transferAmount() {
		System.out.println( "tranfer amount from Savings Bank Account using  netbanking");
		
	}
	
//	public NetBanking yasar() {
//		System.out.println("yasar arafath");
//		return null;
	//}
}
class CurrentAccount extends Account{
	//override the abstract method
	@Override
	public void displayAccountInfo()
	{
		System.out.println("Current Account");
	}
}