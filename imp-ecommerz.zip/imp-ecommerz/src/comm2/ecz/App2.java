package comm2.ecz;

import java.util.ArrayList;
import java.util.Scanner;

public class App2 {


		public static void main(String[] args) {

			System.out.println("Welcome to Ecommerce World");
			System.out.println("/n****************Adding books to the cart **************");
			ArrayList<Product> shoppingCart = new ArrayList<Product>();
			Product product1 = new Product();
			product1.productId = 1;
			product1.productName = "book1";
			product1.price = 100.25f;
			product1.available = "true";
			shoppingCart.add(product1);
			Product product2 = new Product(2,"book2",200.0f,"true");
			shoppingCart.add(product2);
			Product product3 = new Product(3,"book3",150.75f,"true");
			shoppingCart.add(product3);
			Scanner sc= new Scanner(System.in);
			String n1 = sc.nextLine();	
			String n2 = sc.nextLine();			
			String n3 = sc.nextLine();	
			String n4 = sc.nextLine();	
			int n11 = Integer.parseInt(n1);
			float n33 = Float.parseFloat(n3);
			
			
            Product product4 = new Product(n11,n2,n33,n4);
            shoppingCart.add(product4);
            
			
			System.out.println("*************Displaying all the books***************");
			for(Product product : shoppingCart)
			{
				product.displayDetails();
			}
			
			
			
			
			System.out.println("/n***************Searching a book*****************");
			String searchbook = sc.nextLine();
			boolean foundbook = false;
			for (Product book : shoppingCart) {
				if (searchbook.equalsIgnoreCase(book.productName)) {

					foundbook = true;
				}
			}
			if (foundbook) {
				System.out.println("found the book");
			} else {
				System.out.println("book not found so it will be added");
			    Product product5 = new Product(5,searchbook,300,"true");
			    
			    shoppingCart.add(product5);
			    
			}
			System.out.println("/n***************UPDATED BOOK LIST**********");
			for (Product book : shoppingCart) {
                 book.displayDetails();
			}
			System.out.println("********************Removing updated books************");
			String removebook = sc.nextLine();
		boolean found = false;
			for (Product book : shoppingCart) {
				if (removebook.equalsIgnoreCase(book.productName)) {
					shoppingCart.remove(book);
					found = true;
					break;
				} 
			}
		if(!found) {
				System.out.println("It is not in the book list");
			
			}
			System.out.println("/n***************UPDATED BOOK LIST**********");
			for (Product book : shoppingCart) {
                 book.displayDetails();
			}
			
			
		}
}
		
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
			
//			Scanner sc = new Scanner(System.in);
//			String book1 = sc.nextLine();
//			String book2 = sc.nextLine();
//			String book3 = sc.nextLine();
//			shoppingCart.add(book1);
//			shoppingCart.add(book2);
//			shoppingCart.add(book3);

//			System.out.println("/n***************Displaying the books**********");
//			for (String book : shoppingCart) {
//
//				System.out.println(book);
//			}
//
//			System.out.println("/n***************Searching a book*****************");
//			String searchbook = sc.nextLine();
//			boolean foundbook = false;
//			for (String book : shoppingCart) {
//				if (searchbook.equalsIgnoreCase(book)) {
//
//					foundbook = true;
//				}
//			}
//			if (foundbook) {
//				System.out.println("found the book");
//			} else {
//				System.out.println("book not found so it will be added");
//				shoppingCart.add(searchbook);
//			}
//			System.out.println("/n***************UPDATED BOOK LIST**********");
//			for (String book : shoppingCart) {
//
//				System.out.println(book);
//			}
//
//			System.out.println("********************Removing updated books************");
//			String removebook = sc.nextLine();
////			for (String book : shoppingCart) {
////				if (removebook.equalsIgnoreCase(book)) {
////					shoppingCart.remove(removebook);
////				} else {
////					System.out.println("It is not in the book list");
////				}
////			}
//	    
//			System.out.println("***************Updated booklist after removing********** ");
//			boolean removed = shoppingCart.remove(removebook);
//			if(removed) {
//				System.out.println("Removed book : " + removebook);
//			}
//			else {
//				System.out.println("It is not in the book list");
//			}
//			System.out.println("/n ****************Sorting the booklist***************");
//			Collections.sort(shoppingCart);
//			for(String book :shoppingCart )
//			{
//				System.out.println(book);
//			
//			}
//		}
//	}
//
//}
