package comm2.ecz;


public class Product {
	public int productId;
	public String productName;
	public float price;
	public String available;
	
	
	public Product() {
		
	}
	
	public Product(int pProductId,String pProductName ,float pPrice,String pAvailable)
	{
		productId = pProductId;
		productName = pProductName;
		price = pPrice;
		available = pAvailable;

	}
	
	public void displayDetails()
	{
	System.out.println("\n \n Book Id :" +  productId);
	System.out.println("Book Name :" +  productName);
	System.out.println("Book Price :" +  price);
	System.out.println("Book Availability :"  +  available);
	}
}
