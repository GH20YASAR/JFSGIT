//package jdbc;
//
//public class InsertStatementUserInputApp1 {
//	
//
//
//	public class Product {
//		public int productId;
//		public String productName;
//		public float price;
//		public boolean available;
//		
//		
//		public Product(int pProductId,String pProductName ,float pPrice,boolean pAvailable)
//		{
//			productId = pProductId;
//			productName = pProductName;
//			price = pPrice;
//			available = pAvailable;
//
//		}
//		
//		public void displayDetails()
//		{
//		System.out.println("\n \n Book Id :" +  productId);
//		System.out.println("Book Name :" +  productName);
//		System.out.println("Book Price :" +  price);
//		System.out.println("Book Availability :"  +  available);
//		}
//	}
