package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Statement;

public class StatementVsPreparedStatement {
	
	public static void main(String[] args) {
		// Establish a connection
		testStatement();
		testPreparedStatement();
	}

	private static void testStatement() {
		try {
			Connection connection 
			= DriverManager.getConnection("jdbc:mysql://localhost:3306/jfsbotdb", "root", "mysql");
			System.out.println("Connected Successfully");
			long startTime = System.currentTimeMillis();
			// CREATE THE STATEMENT
			Statement statement = connection.createStatement();
			// CREATE THE SQL QUERY STRING
			for(int row = 1; row < 5000; row++) {
				String insertStatement = "INSERT INTO PRODUCT VALUES (" + row + ", 'P" + row + "'," + row  + ", '" + row + "')";
		
				// EXECUTE THE QUERY 
				int rowsAffected  = statement.executeUpdate(insertStatement);
				
				// CHECK IF DATA IS INSERTED SUCCESSFULLY 
//				if(rowsAffected > 0 ) {
//					System.out.println("Inserted Record successfully!");
//				}
//				else
//				{
//					System.out.println("The record could not be inserted....");
//				}			
			}

			long endTime = System.currentTimeMillis();
			System.out.println(endTime-startTime);
			
		} catch (SQLException sqlException) {
			System.out.println("Database Connection Problmens " + sqlException);
		}
	}
		private static void testPreparedStatement() {
			try {
				Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/jfsbotdb", "root", "mysql");
				System.out.println("Connected Successfully");
				long startTime = System.currentTimeMillis();
				String query = "INSERT INTO PRODUCT VALUES (?,?,?,?)";
				// CREATE THE SQL QUERY STRING
					// CREATE THE STATEMENT
					PreparedStatement preparedStatement = connection.prepareStatement(query);
					for(int row = 1; row < 5000; row++) {
						preparedStatement.setInt(1, row);
						preparedStatement.setString(2, "P"+row);
						preparedStatement.setInt(3, row);
						preparedStatement.setInt(4, row);
					// EXECUTE THE QUERY 
					int rowsAffected  = preparedStatement.executeUpdate();
					
					// CHECK IF DATA IS INSERTED SUCCESSFULLY 
//					if(rowsAffected > 0 ) {
//						System.out.println("Inserted Record successfully!");
//					}
//					else
//					{
//						System.out.println("The record could not be inserted....");
//					}			
				}

				long endTime = System.currentTimeMillis();
				System.out.println(endTime-startTime);
				
			} catch (SQLException sqlException) {
				System.out.println("Database Connection Problmens " + sqlException);
			}
	}
}