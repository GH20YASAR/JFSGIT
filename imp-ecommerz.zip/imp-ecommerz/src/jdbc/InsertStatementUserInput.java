package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Scanner; 

public class InsertStatementUserInput {
    public static void main(String[] args) {
    	
    	int productId;
    	String productName;
         float price;
    	String available;
    	Scanner scanner = new Scanner(System.in);
    	System.out.println("******************************Welcome to Ecommerce****************************");
		
		for(int i=0 ; i<3;i++)
		{
			System.out.println("ENTER PRODUCTID :");
			String n1 = scanner.nextLine();	
			System.out.println("ENTER PRODUCTNAME:");
			
         productName= scanner.nextLine();	
         System.out.println("ENTER PRICE :");
		String n3 = scanner.nextLine();
		System.out.println("Availability");
		 available = scanner.nextLine();	
		productId = Integer.parseInt(n1);
	      price = Float.parseFloat(n3);
	      
	     
        // Establish a connection
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/yasar", "root", "mysql");
            System.out.println("Connected Successfully");
            //CREATE THE SQL QUERY STRING
            String sqlInsert = "INSERT INTO PRODUCT VALUES("+productId+",'"+ productName +"',"+price+",'"+available+"');";
            // CREATE THE STATEMENT
            Statement statement = connection.createStatement();
            //Execute the query and get the result set
            int rowsaffected = statement.executeUpdate(sqlInsert);
            //Iterate through the result set and display the data
          if (rowsaffected > 0)
          {
        	  System.out.println("Inserted rows successfully");
          }
        	  else {
        		  System.out.println("records could not be inserted");
        	  }
			
        
		}
            
         catch (SQLException sqlException) {
            System.out.println("Database Connection Problmens " + sqlException);
        }
    }
		
		   try {
	            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/yasar", "root", "mysql");
	            System.out.println("Connected Successfully");
	            System.out.println("******************************************Updating the records************************************");
	            System.out.println("Give the book name  you have to chnage and the product id from where you have to change");
	           String u1 = scanner.nextLine();
	           String u12 = scanner.nextLine();
	           String u2 = scanner.nextLine();
	           String u21 = scanner.nextLine();
	           int u122 = Integer.parseInt(u12);
	           int u212 = Integer.parseInt(u21);
	           
	           
	            String sqlUpdate1 = "UPDATE PRODUCT SET PRODUCT_NAME = '"+u1+"' WHERE PRODUCT_ID = "+u122+";";
	            String sqlUpdate2 =   "UPDATE PRODUCT SET PRODUCT_NAME = '"+u2+"' WHERE PRODUCT_ID = "+u212+";";
	            System.out.println( sqlUpdate1);
	            System.out.println(sqlUpdate2);
	            
	            Statement statement = connection.createStatement();
	            
	            int rowsaffected1 = statement.executeUpdate(sqlUpdate1);
	            int rowsaffected2 = statement.executeUpdate(sqlUpdate2);
	            
	            
	          if ((rowsaffected1 > 0) && (rowsaffected2 > 0))
	          {
	        	  System.out.println("updated records successfully");
	          }
	        	  else {
	        		  System.out.println("records could not be updated");
	        	  }
	          
	          System.out.println("*************************************************Deleting the records*********************************");
	          System.out.println("Give the productid :");
	          String d1 = scanner.nextLine();
	          int d12 = Integer.parseInt(d1);
	
	          
	          
	          
	          String sqldelete = "DELETE FROM PRODUCT WHERE PRODUCT_ID = "+d12+";";
	          int rowsaffected3 = statement.executeUpdate(sqldelete);
	          
	          
			if (rowsaffected3 > 0)
	          {
	        	  System.out.println("deleted  records successfully ");
	          }
	          else {
	        	  System.err.println("records could not be deleted");
	          }
			
			
			
			   System.out.println("************************************************searching the records*********************************");
		          System.out.println("Give the productid :");
		          String s1 = scanner.nextLine();
		          int s12 = Integer.parseInt(s1);
		          String sqlsearch = "SELECT * FROM PRODUCT WHERE PRODUCT_ID ="+s12+"; ";
		          ResultSet resultSet1   = statement.executeQuery(sqlsearch);
		          
				
		        while(resultSet1.next())
	            {
	            	productId = resultSet1.getInt("PRODUCT_ID");
	            	 productName = resultSet1.getString("PRODUCT_NAME");
	             price = resultSet1.getInt("PRICE");
	            	 available = resultSet1.getString("AVAILABLE");
	            	 System.out.println("Printing the searched books");
	            	System.out.println(productId +"   "+productName+"  "+price+"  "+available);
	            	
	            }
	          
		        
		        System.out.println("************************************************Displaying the records**********************************");
	          
	          String sqlDisplay = "SELECT PRODUCT_ID,PRODUCT_NAME,PRICE,AVAILABLE FROM PRODUCT";
	          
	          ResultSet resultSet2 = statement.executeQuery(sqlDisplay);
	            
	            while(resultSet2.next())
	            {
	            	productId = resultSet2.getInt("PRODUCT_ID");
	            	 productName = resultSet2.getString("PRODUCT_NAME");
	             price = resultSet2.getInt("PRICE");
	            	 available = resultSet2.getString("AVAILABLE");
	            	System.out.println(productId +"   "+productName+"  "+price+"  "+available);
	            	
	            }
	            
	       } catch (SQLException sqlException) {
	            System.out.println("Database Connection Problmens " + sqlException);
	        }
	    }
}
