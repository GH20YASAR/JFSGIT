package jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class DeleteStatementEx {
    public static void main(String[] args) {
        // Establish a connection
        try {
            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/yasar", "root", "mysql");
            System.out.println("Connected Successfully");
            //CREATE THE SQL QUERY STRING
            String sqlDelete = "DELETE FROM PRODUCT WHERE PRODUCT_ID = 1;";
;
            // CREATE THE STATEMENT
            Statement statement = connection.createStatement();
            //Execute the query and get the result set
            int rowsaffected = statement.executeUpdate(sqlDelete);
            //Iterate through the result set and display the data
          if (rowsaffected > 0)
          {
        	  System.out.println("Deleted record successfully");
          }
        	  else {
        		  System.out.println("records could not be deleted");
        	  }
			
          
            
        } catch (SQLException sqlException) {
            System.out.println("Database Connection Problmens " + sqlException);
        }
    }
}