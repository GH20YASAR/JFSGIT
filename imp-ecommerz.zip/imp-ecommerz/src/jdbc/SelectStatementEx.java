//package jdbc; 
//
//import java.sql.Connection;
//import java.sql.DriverManager;
//import java.sql.ResultSet;
//import java.sql.SQLException;
//import java.sql.Statement;
//
//public class SelectStatementEx {
//    public static void main(String[] args) {
//        // Establish a connection
//        try {
//            
//            Connection connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/sakila", "root", "mysql");
//            System.out.println("Connected Successfully");
//            //CREATE THE SQL QUERY STRING
//            String sqlSelect = "SELECT ACTOR_ID, FIRST_NAME,LAST_NAME FROM ACTOR";
//            // CREATE THE STATEMENT
//            Statement statement = connection.createStatement();
//            //Execute the query and get the result set
//            ResultSet resultset = statement.executeQuery(sqlSelect);
//            //Iterate through the result set and display the data
//            while(resultset.next())
//            {
//            	int actorId = resultset.getInt(1);
//            	String firstName = resultset.getString(2);
//            	String lastName = resultset.getString("LAST_NAME");
//            	System.out.println(actorId +""+firstName+""+lastName);
//            	
//            }
//           
//            
//        } catch (SQLException sqlException) {
//            System.out.println("Database Connection Problmens " + sqlException);
//        }
//    }