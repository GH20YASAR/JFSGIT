package com.fmcgglobal.model;

import javax.annotation.ManagedBean;

@ManagedBean
public class Product extends Object {
	private String productId;
	private String productName;
	private int price;
	private int availableQuantity;
	private String expiryDate;

	public Product(String productId, String productName, int price, int availableQuantity, String expiryDate)

	{
		this.productId = productId;
		this.productName = productName;
		this.price = price;
		this.availableQuantity = availableQuantity;
		this.expiryDate = expiryDate;

	}

	public Product(String productName, String productId) {
		this.productName = productName;
		this.productId = productId;
	}

	public Product(String productId) {
		this.productId = productId;
	}

	
	public Product() {
		// TODO Auto-generated constructor stub
	}

	public String getProductId() {
		return productId;
	}

	public String getProductName() {
		return productName;
	}

	public int getPrice() {
		return price;
	}

	public int getAvailableQuantity() {
		return availableQuantity;
	}

	public String getExpiryDate() {
		return expiryDate;
	}

	@Override
	public String toString() {
		return " productId :" + productId + "\n productName :" + productName + "\n price :" + price
				+ "\n availableQuantity :" + availableQuantity + "\n expiryDate :" + expiryDate
				+ "\n\n";
	}
}
