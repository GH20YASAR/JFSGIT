package com.fmcgglobal.ui;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.time.LocalDate;
import java.util.Date;
import java.util.List;
import java.util.Scanner;

import com.fmcgglobal.model.Products;
import com.fmcgglobal.repository.ProductRepository;

public class FmcgGlobalApp {
	Scanner scanner = null;
	ProductRepository productRepository = null;

	public static void main(String[] args) {
		FmcgGlobalApp fmcgGlobalApp = new FmcgGlobalApp();
		fmcgGlobalApp.displayMenu();
	}

	public FmcgGlobalApp() {
		scanner = new Scanner(System.in);
		productRepository = new ProductRepository();
	}

	private void displayMenu() {
		
		while_label: while (true) {
			System.out.println("---------------------------------------------------------WELCOME TO FMCGGLOBAL-------------------------------------------------------------------");
			System.out.println("                                                  Here you get all the Products u need                      ");
			System.out.println("================================================================================================================================================================================================");
			System.out.print("\n1. DISPLAY PRODUCTS");
			System.out.print("                           2. ADD PRODUCT");
			System.out.print("                           3. UPDATE PRODUCT");
			System.out.println("             4. DELETE PRODUCT");
			System.out.print("\n5.DISPLAY  PRODUCTS WITH CALLABLE STATEMENT");
			System.out.print("   6. ADD PRODUCT WITH PREPARED STATEMENT");
			System.out.print("   7. SEARCH PRODUCT");
			System.out.println("             0. EXIT");
			System.out.print("\n\nENTER CHOICE : ");
			int choice = Integer.parseInt(scanner.nextLine());
			System.out.println();

			switch (choice) {
			case 1: {
				findAllProducts();
				break;
			}
			case 2: {
				saveProduct();
				break;
			}
			case 3: {
				updateProduct();
				break;
			}
			case 4: {
				deleteProduct();
				break;
			}
			case 5: {
				findAllProductsWithCallableStatement();
				break;
			}
			case 6: {
				saveProductWithPreparedStatement();
				break;
			}
			case 7: {
				enableFilterProduct();
				break;
			}
			case 0: {
				break while_label;
			}

			default: {
				System.out.println("Enter a valid option");
			}
			}
		}
		System.out.println("THANK YOU !!!");
		System.out.println("COME AGAIN");
	}
	
	private void findAllProducts() {
		List<Products> productsList = productRepository.findAll();
		if (productsList.size() > 0) {
			productsList.forEach(System.out::println);
		} else {
			System.out.println("NO PRODUCTS");
		}
	}

	private void findAllProductsWithCallableStatement() {
		List<Products> productsList = productRepository.findAllWithCallableStatement();
		if (productsList.size() > 0) {
			productsList.forEach(System.out::println);
		} else {
			System.out.println("NO PRODUCTS");
		}
	}
	
	private void saveProduct() {
//		ACCEPT PRODUCT DETAILS FROM USER
		System.out.println("ENTER PRODUCT_ID");
        String piString = scanner.nextLine();
		System.out.println("ENTER PRODUCT_NAME");
		String ciString = scanner.nextLine();
		System.out.println("ENTER PRICE");
		int price = Integer.parseInt(scanner.nextLine());
		System.out.println("ENTER AVAILABLE_QUANTITY");
		int qa = Integer.parseInt(scanner.nextLine());
		System.out.println("ENTER EXPIRY_DATE");
		String edString = scanner.nextLine();
		Date parsedDate = null;
		String parsedDateteString = null;
		String expiryDateString = null;
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		try {
			parsedDate = simpleDateFormat.parse(edString);

			parsedDateteString = simpleDateFormat.format(parsedDate);

			LocalDate expiryDate = LocalDate.parse(parsedDateteString);
			expiryDateString = expiryDate.getYear() + "-" + expiryDate.getMonthValue() + "-"
					+ expiryDate.getDayOfMonth();

		}

		catch (ParseException parseException) {
			System.out.println("Exception : Invalid date format " + parseException);
		}

		Products product = new Products(piString, ciString, price, qa, expiryDateString);
		productRepository.save(product);
	}

	private void saveProductWithPreparedStatement() {
//		ACCEPT PRODUCT DETAILS FROM USER
		System.out.println("ENTER PRODUCT_ID");
        String piString = scanner.nextLine();
		System.out.println("ENTER PRODUCT_NAME");
		String ciString = scanner.nextLine();
		System.out.println("ENTER PRICE");
		int price = Integer.parseInt(scanner.nextLine());
		System.out.println("ENTER AVAILABLE_QUANTITY");
		int qa = Integer.parseInt(scanner.nextLine());
		System.out.println("ENTER EXPIRY_DATE");
		String edString = scanner.nextLine();
		Date parsedDate = null;
		String parsedDateteString = null;
		String expiryDateString = null;
		SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
		try {
			parsedDate = simpleDateFormat.parse(edString);

			parsedDateteString = simpleDateFormat.format(parsedDate);

			LocalDate expiryDate = LocalDate.parse(parsedDateteString);
			expiryDateString = expiryDate.getYear() + "-" + expiryDate.getMonthValue() + "-"
					+ expiryDate.getDayOfMonth();

		}

		catch (ParseException parseException) {
			System.out.println("Exception : Invalid date format " + parseException);
		}

		Products product = new Products(piString, ciString, price, qa, expiryDateString);
		productRepository.saveWithPreparedStatement(product);
	}

	private void updateProduct() {
		System.out.println("Enter the NEW PRODUCTNAME of Product :");
		String productName = scanner.nextLine();
		System.out.println("Enter the EXISTING PRODUCTID  where we have to change PRODUCTNAME :");
		String productId = scanner.nextLine();
		Products product = new Products(productName, productId);
		productRepository.update(product);

	}

	private void deleteProduct() {
		System.out.println("Enter the PRODUCTID we have to delete :");
		String productId = scanner.nextLine();
		Products product = new Products(productId);
		productRepository.delete(product);
	}

	private void enableFilterProduct() {
		System.out.println("Enter the PRODUCTID which we want to search :");
		String productId = scanner.nextLine();
		Products product = new Products(productId);
		List<Products> productsList1 = productRepository.filter(product);
		if (productsList1.size() > 0) {
			productsList1.forEach(System.out::println);
		} else {
			System.out.println("NO PRODUCTS");
		}
	}

}
