package com.fmcgglobal.repository;

import java.sql.CallableStatement;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;

import com.fmcgglobal.model.Products;

public class MySQLDBConnection {
	public static Connection getConnection() {
		Connection connection = null;
		// Establish a connection
		try {
//					LOAD THE DRIVER
			Class.forName("com.mysql.cj.jdbc.Driver");
//					ESTABLISH THE CONNECTION
			connection = DriverManager.getConnection("jdbc:mysql://localhost:3306/FMCGGLOBALDB", "root", "mysql");
//System.out.println("Connection established");
			return connection;
		} catch (ClassNotFoundException classNotFoundException) {
			System.out.println("Driver could not be loaded " + classNotFoundException);
		} catch (SQLException sqlException) {
			System.out.println("Database Connection Problems " + sqlException);
		}
		
		return null;
		
	}

	public static ResultSet getResultSet(String selectQuery) {
		try {
//			GET CONNECTION
			Connection connection = getConnection();
			// CREATE THE STATEMENT
			Statement statement = connection.createStatement();
			// EXECUTE THE QUERY AND GET THE RESULT SET
			
			
			ResultSet resultSet = statement.executeQuery(selectQuery);
		
			return resultSet;
		} catch (SQLException sqlException) {
			System.out.println("Cannot execute query : " + sqlException);
		}
		return null;
	}
	
	
	
	public static ResultSet getResultSetWithCallableStatement(String query) {
		try {
//			GET CONNECTION
		 	Connection connection = getConnection();
			// CREATE THE STATEMENT
			CallableStatement callablestatement = connection.prepareCall(query);
			// EXECUTE THE QUERY AND GET THE RESULT SET
			
			
			ResultSet resultSet = callablestatement.executeQuery();
			
			return resultSet;
		} catch (SQLException sqlException) {
			System.out.println("Cannot execute query : " + sqlException);
		}
		
		return null;
	}
	
	
	public static int saveRecord(String insertQuery) {
		int rowsInserted = 0;
		try {
			// CREATE THE STATEMENT
			Statement statement = getConnection().createStatement();
			// EXECUTE THE QUERY AND GET THE RESULT SET
			rowsInserted  = statement.executeUpdate(insertQuery);
			
			// CHECK IF DATA IS INSERTED SUCCESSFULLY 
			if(rowsInserted > 0 ) {
				System.out.println("Inserted Record successfully!");
			}
			else
			{
				System.out.println("The record could not be saved....");
			}
		} catch (SQLException sqlException) {
			System.out.println("Cannot execute query : " + sqlException);
		}
		
		return rowsInserted;
	}
	
	
	public static int saveRecordWithPreparedStatement(Products product) {
		int rowsInserted = 0;
		try {
			
			// CREATE THE INSERT QUERY
			String query = "INSERT INTO PRODUCTS VALUES (?,?,?,?,?)";
			
			System.out.println(query);
			
			PreparedStatement preparedStatement = getConnection().prepareStatement(query);
			preparedStatement.setString(1, product.getProductId());
			preparedStatement.setString(2, product.getProductName());
			preparedStatement.setInt(3, product.getPrice());
			preparedStatement.setInt(4, product.getAvailableQuantity());
			preparedStatement.setString(5, product.getExpiryDate());
			

			rowsInserted  = preparedStatement.executeUpdate();
			
			// CHECK IF DATA IS INSERTED SUCCESSFULLY 
			if(rowsInserted > 0 ) {
				System.out.println("Inserted Record successfully!");
			}
			else
			{
				System.out.println("The record could not be saved....");
			}
		} catch (SQLException sqlException) {
			System.out.println("Cannot execute query : " + sqlException);
		}
		return rowsInserted;
	}
	
	
	
	public static int updateRecord(String updateQuery) {
		int rowsUpdated = 0;
		try {
			// CREATE THE STATEMENT
			Statement statement = getConnection().createStatement();
			// EXECUTE THE QUERY AND GET THE RESULT SET
			rowsUpdated = statement.executeUpdate(updateQuery);
			
			// CHECK IF DATA IS INSERTED SUCCESSFULLY 
			if(rowsUpdated > 0 ) {
				System.out.println("Updated Record successfully!");
			}
			else
			{
				System.out.println("The record could not be updated....");
			}
		} catch (SQLException sqlException) {
			System.out.println("Cannot execute query : " + sqlException);
		}
		return rowsUpdated;
		
	}

	public static int 	deleteRecord(String deleteQuery) {
		int rowsDeleted = 0;
		try {
			// CREATE THE STATEMENT
			Statement statement = getConnection().createStatement();
			// EXECUTE THE QUERY AND GET THE RESULT SET
			rowsDeleted= statement.executeUpdate(deleteQuery);
			
			// CHECK IF DATA IS INSERTED SUCCESSFULLY 
			if(rowsDeleted > 0 ) {
				System.out.println("DELETED Record successfully!");
			}
			else
			{
				System.out.println("The record could not be DELETED....");
			}
		} catch (SQLException sqlException) {
			System.out.println("Cannot execute query : " + sqlException);
		}
		return rowsDeleted;
	
	
	
}
	public static ResultSet getResultSet1(String searchQuery) {
	try {
//		GET CONNECTION
		Connection connection = getConnection();
		// CREATE THE STATEMENT
		Statement statement = connection.createStatement();
		// EXECUTE THE QUERY AND GET THE RESULT SET
		ResultSet resultSet = statement.executeQuery(searchQuery);
		return resultSet;
	} catch (SQLException sqlException) {
		System.out.println("Cannot execute query : " + sqlException);
	}
	return null;
}
}




