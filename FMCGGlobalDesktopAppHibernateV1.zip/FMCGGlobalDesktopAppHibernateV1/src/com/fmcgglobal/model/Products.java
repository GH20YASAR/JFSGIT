package com.fmcgglobal.model;

public class Products extends Object {
	private String productId;
	private String productName;
	private String supplierId;
	private String categoryId;
	private int price;
	private int availabilityQuantity;
	private int reorderLevel;
	private String expiryDate;
	private String  discontinued;
	
	public Products(String productId,String productName, String supplierId,String categoryId,int price,int availabilityQuantity, int reorderLevel,String expiryDate ,String  discontinued) 
		
		{
		this. productId =  productId;
		this.productName = productName;
		this. supplierId = supplierId;
		this. categoryId = categoryId;
		this. price = price;
		this.availabilityQuantity = availabilityQuantity;
		this.reorderLevel = reorderLevel;
		this. expiryDate = expiryDate;
		this. discontinued = discontinued;
		}
	
	public Products(String productName, String productId)
	{
		this.productName = productName;
		this.productId = productId;
	}
	
		
	public Products(String productId)
	{
		this.productId = productId;
	}

		
	
	public Products() {
		// TODO Auto-generated constructor stub
	}

	public String getProductId() {
		return productId;
	}




	public String getProductName() {
		return productName;
	}




	public String getSupplierId() {
		return supplierId;
	}




	public String getCategoryId() {
		return categoryId;
	}




	public int getPrice() {
		return price;
	}




	public int getAvailabilityQuantity() {
		return availabilityQuantity;
	}




	public int getReorderLevel() {
		return reorderLevel;
	}




	public String getExpiryDate() {
		return expiryDate;
	}



public String getDiscontinued() {
		return discontinued;
	}



@Override
	public String toString() {
		return " productId :" + productId + "\n productName :" + productName + "\n supplierId :" + supplierId
				+ "\n categoryId :" + categoryId + "\n price :" + price + "\n availabilityQuantity :" + availabilityQuantity
				+ "\n reorderLevel :" + reorderLevel + "\n expiryDate :" + expiryDate + "\n discontinued :" + discontinued+
				"\n\n";
	}
}




	
	
	
	
	
	
