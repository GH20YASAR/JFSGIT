package com.fmcgglobal.test;
import com.fmcgglobal.repository.MySQLDBConnection;

public class MySQLDBConnectionTest {
	public static void main(String[] args) {
		MySQLDBConnection.getConnection();
	}
}