package com.fmcgglobal.entity;



import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.Table;

@Entity
@Table(name = "PRODUCTS")
public class Product {
	@Id
	// productID / PRODUCT_ID
	@Column(name = "PRODUCT_ID")
	private String productId;
	// productName / PRODUCT_NAME
	@Column(name = "PRODUCT_NAME")
	private String productName;
	@Column (name = "SUPPLIER_ID")
	private String supplierId;
	@Column (name = "CATEGORY_ID")
	private String categoryId;
	private int price;
	@Column(name = "AVAILABILITY_QUANTITY")
	private int availabilityQuantity;
	@Column (name = "REORDER_LEVEL")
	private int reorderLevel;
	@Column (name = "EXPIRY_DATE")
	private String expiryDate;
	private String  discontinued;
	
	
	public Product() {

	}
	
	
	public Product(String productId,String productName, String supplierId,String categoryId,int price,int availabilityQuantity, int reorderLevel,String expiryDate ,String  discontinued) 
	
	{
	this. productId =  productId;
	this.productName = productName;
	this. supplierId = supplierId;
	this. categoryId = categoryId;
	this. price = price;
	this.availabilityQuantity = availabilityQuantity;
	this.reorderLevel = reorderLevel;
	this. expiryDate = expiryDate;
	this. discontinued = discontinued;
	}

	
	
	
	
	

//	@Override
//	public String toString() {
//		return "Product [productId=" + productId + ", productName=" + productName + ", price=" + price + ", quantity="
//				+ quantity + "]";
//	}

	public String getProductId() {
		return productId;
	}


	public void setProductId(String productId) {
		this.productId = productId;
	}


	public String getProductName() {
		return productName;
	}


	public void setProductName(String productName) {
		this.productName = productName;
	}


	public String getSupplierId() {
		return supplierId;
	}


	public void setSupplierId(String supplierId) {
		this.supplierId = supplierId;
	}


	public String getCategoryId() {
		return categoryId;
	}


	public void setCategoryId(String categoryId) {
		this.categoryId = categoryId;
	}


	public int getPrice() {
		return price;
	}


	public void setPrice(int price) {
		this.price = price;
	}


	public int getAvailabilityQuantity() {
		return availabilityQuantity;
	}


	public void setAvailabilityQuantity(int availabilityQuantity) {
		this.availabilityQuantity = availabilityQuantity;
	}


	public int getReorderLevel() {
		return reorderLevel;
	}


	public void setReorderLevel(int reorderLevel) {
		this.reorderLevel = reorderLevel;
	}


	public String getExpiryDate() {
		return expiryDate;
	}


	public void setExpiryDate(String expiryDate) {
		this.expiryDate = expiryDate;
	}


	public String getDiscontinued() {
		return discontinued;
	}


	public void setDiscontinued(String discontinued) {
		this.discontinued = discontinued;
	}


	@Override
	public String toString() {
		return "productId=" + productId + " , productName=" + productName + " , supplierId=" + supplierId
				+ " , categoryId=" + categoryId + " , price=" + price + " , availabilityQuantity=" + availabilityQuantity
				+ " , reorderLevel=" + reorderLevel + " , expiryDate=" + expiryDate + " , discontinued=" + discontinued
				;
	}


}