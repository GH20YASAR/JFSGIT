package com.fmcgglobal.repository;


import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import com.fmcgglobal.model.Products;


public class ProductRepository {
	public List<Products> findAll() {
		//LIST TO STORE PRODUCTS
		List<Products> productsList = new ArrayList<Products>();
		ResultSet resultSet = MySQLDBConnection.getResultSet("SELECT * FROM PRODUCTS"); 
		// ITERATE THROUGH THE RESULT SET AND CREATE THE PRODUCT MODEL
		try {
			while(resultSet.next()) {
//				CREATE TABLE PRODUCTS(PRODUCT_ID CHAR(5) PRIMARY KEY NOT NULL,PRODUCT_NAME VARCHAR(20) NOT NULL,SUPPLIER_ID CHAR(5) NOT NULL,CATEGORY_ID CHAR(5) NOT NULL,PRICE INT,AVALIBILITY_QUALITY CHAR(5),REORDER_LEVEL INT ,EXPIRY_DATE DATE,DISCONTINOUED CHAR(5),FOREIGN KEY (SUPPLIER_ID)  REFERENCES SUPPLIERS(SUPPLIER_ID),FOREIGN KEY (CATEGORY_ID) REFERENCES CATEGORIES(CATEGORY_ID));
				String productId = resultSet.getString("PRODUCT_ID");
				String productName = resultSet.getString("PRODUCT_NAME");
				String  supplierId = resultSet.getString("SUPPLIER_ID");
				String categoryId  = resultSet.getString("CATEGORY_ID");
				int price = resultSet.getInt("PRICE");
				int availabilityQuantity = resultSet.getInt("AVAILABILITY_QUANTITY");
				int reorderLevel = resultSet.getInt("REORDER_LEVEL");
				String expiryDate = resultSet.getString("EXPIRY_DATE");
				String discontinued = resultSet.getString("DISCONTINUED");
				 
				//CREATE A PRODUCT OBJECT FOR THE PRODUCT
				Products product = new Products(productId,productName,supplierId,categoryId,price,availabilityQuantity,reorderLevel,expiryDate,discontinued);
				productsList.add(product);
			}
			return productsList;
		} catch (SQLException sqlException) {
			System.out.println("Problem in Result Set " + sqlException);
		}
		return null;
	}
	
	public Products save(Products product) {
		// CREATE THE INSERT QUERY
		String insertQuery = "INSERT INTO PRODUCTS VALUES ('" + product.getProductId() + "','"
				+ product.getProductName() + "','" + product.getSupplierId() + "','" + product.getCategoryId() + "'," + product.getPrice() + "," +product.getAvailabilityQuantity()+ ","+product.getReorderLevel()+",'"+product.getExpiryDate()+"','"+product.getDiscontinued()+"');";
		System.out.println(insertQuery);
		
		MySQLDBConnection.saveRecord(insertQuery);
		return product;
	}
	
	public void update(Products product){
		String updateQuery = "UPDATE PRODUCTS SET PRODUCT_NAME = '"+product.getProductName()+"' WHERE PRODUCT_ID = '"+product.getProductId()+"';";
		MySQLDBConnection.updateRecord(updateQuery);
		
	}
	
	public void delete(Products product) {
		String deleteQuery = "DELETE FROM PRODUCTS WHERE PRODUCT_ID ='"+product.getProductId()+"';";
		MySQLDBConnection.deleteRecord(deleteQuery);
		
		
	}
	
	public List<Products> filter() {
		List<Products> productsList1 = new ArrayList<Products>();
		ResultSet resultSet = MySQLDBConnection.getResultSet1("SELECT * FROM PRODUCTS WHERE PRODUCT_ID ='P0003';"); 
		// ITERATE THROUGH THE RESULT SET AND CREATE THE PRODUCT MODEL
		try {
			while(resultSet.next()) {
//				CREATE TABLE PRODUCTS(PRODUCT_ID CHAR(5) PRIMARY KEY NOT NULL,PRODUCT_NAME VARCHAR(20) NOT NULL,SUPPLIER_ID CHAR(5) NOT NULL,CATEGORY_ID CHAR(5) NOT NULL,PRICE INT,AVALIBILITY_QUALITY CHAR(5),REORDER_LEVEL INT ,EXPIRY_DATE DATE,DISCONTINOUED CHAR(5),FOREIGN KEY (SUPPLIER_ID)  REFERENCES SUPPLIERS(SUPPLIER_ID),FOREIGN KEY (CATEGORY_ID) REFERENCES CATEGORIES(CATEGORY_ID));
				String productId = resultSet.getString("PRODUCT_ID");
				String productName = resultSet.getString("PRODUCT_NAME");
				String  supplierId = resultSet.getString("SUPPLIER_ID");
				String categoryId  = resultSet.getString("CATEGORY_ID");
				int price = resultSet.getInt("PRICE");
				int availabilityQuantity = resultSet.getInt("AVAILABILITY_QUANTITY");
				int reorderLevel = resultSet.getInt("REORDER_LEVEL");
				String expiryDate = resultSet.getString("EXPIRY_DATE");
				String discontinued = resultSet.getString("DISCONTINUED");
				Products product = new Products(productId,productName,supplierId,categoryId,price,availabilityQuantity,reorderLevel,expiryDate,discontinued);
				productsList1.add(product);
			}
			return productsList1;
		} catch (SQLException sqlException) {
			System.out.println("Problem in Result Set " + sqlException);
		}
		return null;
	}
	}
	



