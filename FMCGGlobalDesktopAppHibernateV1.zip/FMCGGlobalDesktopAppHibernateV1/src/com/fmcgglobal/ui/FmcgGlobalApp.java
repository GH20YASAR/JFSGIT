//package com.fmcgglobal.ui;
//
//import java.text.ParseException;
//import java.text.SimpleDateFormat;
//import java.time.LocalDate;
//import java.util.Date;
//import java.util.List;
//import java.util.Scanner;
//
//import com.fmcgglobal.model.Products;
//import com.fmcgglobal.repository.ProductRepository;
//
//public class FmcgGlobalApp {
//	Scanner scanner = null;
//	ProductRepository productRepository = null;
//
//
//	public static void main(String[] args) {
//		FmcgGlobalApp fmcgGlobalApp = new FmcgGlobalApp();
//		fmcgGlobalApp.displayMenu();
//	}
//
//	public FmcgGlobalApp() {
//		scanner = new Scanner(System.in);
//		productRepository = new ProductRepository();
//	}
//
//	private void displayMenu() {
//		System.out.println("WELCOME TO FMCGGLOBAL");
//		System.out.println("===================");
//		while_label: while (true) {
//			System.out.println("\n1. DISPLAY PRODUCTS");
//			System.out.println("2. ADD PRODUCT");
//			System.out.println("3. UPDATE PRODUCT");
//			System.out.println("4. DELETE PRODUCT");
//			System.out.println("5.SEARCH PRODUCT");
//			System.out.println("0. EXIT");
//			System.out.print("ENTER CHOICE : ");
//			int choice = Integer.parseInt(scanner.nextLine());
//		System.out.println();
//
//			switch (choice) {
//			case 1: {
//			findAllProducts();
//				break;
//			}
//			case 2: {
//				saveProduct();
//				break;
//			}
//			case 3: {
//				updateProduct();
//				break;
//			}
//			case 4: {
//				deleteProduct();
//				break;
//			}
//			case 5: {
//				enableFilterProduct();
//				break;
//			}
//			case 0: {
//				break while_label;
//			}
//
//			default: {
//				System.out.println("Enter a valid option");
//			}
//			}
//		}
//		System.out.println("THANK YOU !!!");
//		System.out.println("COME AGAIN");
//	}
//
//	private  void findAllProducts() {
//		List<Products> productsList = productRepository.findAll();
//		if (productsList.size() > 0) {
//			productsList.forEach(System.out::println);
//		} else {
//			System.out.println("NO PRODUCTS");
//		}
//	}
//
//	private void saveProduct() {
////		ACCEPT PRODUCT DETAILS FROM USER
//		System.out.println("ENTER PRODUCT_ID");
//		
//		String piString = scanner.nextLine(); 
//		System.out.println("ENTER PRODUCT_NAME");
//		String pnString = scanner.nextLine();
//		System.out.println("ENTER SUPPLIER_ID");
//		String siString = scanner.nextLine();
//		System.out.println("ENTER CATEGORY_ID");
//		String ciString = scanner.nextLine();
//		System.out.println("ENTER PRICE");
//		int price = Integer.parseInt(scanner.nextLine());
//		System.out.println("ENTER AVAILABILITY_QUANTITY");
//		int qa = Integer.parseInt(scanner.nextLine());
//		System.out.println("ENTER REORDER_LEVEL");
//		int re = Integer.parseInt(scanner.nextLine());
//		System.out.println("ENTER EXPIRY_DATE");
//		 String edString = scanner.nextLine();
//		 Date parsedDate = null ;
//		 String parsedDateteString = null;
//		 String expiryDateString = null;
//		    SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");
//	        try {
//	             parsedDate  = simpleDateFormat.parse(edString);
//	          
//	             parsedDateteString = simpleDateFormat.format(parsedDate);
//	            
//           LocalDate expiryDate = LocalDate.parse(parsedDateteString);
//	             expiryDateString = expiryDate.getYear() + "-" + expiryDate.getMonthValue() + "-" +expiryDate.getDayOfMonth();
//            
//	            
//	        }
//	        
//	
//	catch (ParseException parseException) {
//	            System.out.println("Exception : Invalid date format " + parseException);
//	        }
//	        System.out.println("ENTER WHETHER DISCONTINUED OR NOT");
//	    String dcString = scanner.nextLine();
//		Products product = new Products(piString, pnString, siString, ciString,price,qa,re,expiryDateString,dcString);
//		productRepository.save(product);
//	}
//	
//	private void updateProduct() {
//		System.out.println("enter the product name we want to change :");
//		String productName  = scanner.nextLine();
//		System.out.println("enter the product Id  where we have to change ProductName :");
//		String productId = scanner.nextLine();
//		Products product = new Products(productName, productId);
//		productRepository.update(product);
//		
//	}
//	private void deleteProduct() {
//		System.out.println("enter the product ID we have to delete :");
//		String productId = scanner.nextLine();
//		Products product = new Products(productId);
//		productRepository.delete(product);
//	}
//	
//	private void enableFilterProduct() {
//		List<Products> productsList1 = productRepository.filter();
//		if (productsList1.size() > 0) {
//			productsList1.forEach(System.out::println);
//		} else {
//			System.out.println("NO PRODUCTS");
//		}
//	}
//
//	}
//	
//	
//	
//
//
//
//
//
//		
//		
//	
