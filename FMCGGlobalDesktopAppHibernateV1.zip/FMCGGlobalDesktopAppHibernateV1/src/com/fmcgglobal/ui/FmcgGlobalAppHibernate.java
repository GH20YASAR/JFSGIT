package com.fmcgglobal.ui;

import java.util.Scanner;

import com.fmcgglobal.entity.Product;
import com.fmcgglobal.repository.ProductRepositoryHibernate;

public class FmcgGlobalAppHibernate {
	Scanner scanner = null;
	ProductRepositoryHibernate productRepositoryHibernate = null;

	public static void main(String[] args) {
		FmcgGlobalAppHibernate fmcgGlobalAppHibernate= new FmcgGlobalAppHibernate();
		fmcgGlobalAppHibernate.displayMenu();
	}

	public FmcgGlobalAppHibernate() {
		scanner = new Scanner(System.in);
		productRepositoryHibernate = new ProductRepositoryHibernate();
	}

	private void displayMenu() {
		System.out.println("WELCOME TO FMCGGlobal");
		System.out.println("===================");
		while_label: while (true) {
			System.out.println("\n1. FIND PRODUCT");
			System.out.println("2. ADD PRODUCT");
			System.out.println("3. UPDATE PRODUCT");
			System.out.println("4. DELETE PRODUCT");
			System.out.println("0. EXIT");
			System.out.print("ENTER CHOICE : ");
			int choice = Integer.parseInt(scanner.nextLine());
			System.out.println();

			switch (choice) {
			case 1: {
				findProduct();
				break;
			}
			case 2: {
				saveProduct();
				break;
			}
			case 3: {
				updateProduct();
				break;
			}
			case 4: {
				deleteProduct();
				break;
			}
			case 0: {
				break while_label;
			}

			default: {
				System.out.println("Enter a valid option");
			}
			}
		}
		System.out.println("THANK YOU !!!");
		System.out.println("===================");
	}

	private void findProduct() {
		Product product = productRepositoryHibernate.getProductById("P0002");
		if(product != null) {
		System.out.println(product);
		}
		else {
			System.out.println("Product Not Found!!!");
		}
	}

	private void saveProduct() {
//		ACCEPT PRODUCT DETAILS FROM USER
		Product product = new Product("P0005", "Complan", "S0005", "C0005",300,600,100,"2022-04-07","no");
		productRepositoryHibernate.saveProduct(product);
	}

	private void updateProduct() {
//		ACCEPT PRODUCT DETAILS FROM USER
		Product product = productRepositoryHibernate.getProductById("P0002");
		product.setProductName("Viva");
		product.setPrice(200);
		
		productRepositoryHibernate.updateProduct(product);
	}

	private void deleteProduct() {
		String productID = scanner.nextLine();
		Product product = productRepositoryHibernate.getProductById(productID);
		productRepositoryHibernate.removeProduct(product);
	}
}